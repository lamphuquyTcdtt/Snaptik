import { useEffect, useCallback } from "react";
import * as Clipboard from "expo-clipboard";

/**
 * Monitor clipboard for social media links
 */
export function useClipboardMonitor(onLinkDetected: (url: string) => void) {
  const isValidSocialMediaUrl = useCallback((url: string) => {
    const socialMediaPatterns = [
      /tiktok\.com/i,
      /vm\.tiktok\.com/i,
      /instagram\.com/i,
      /instagr\.am/i,
      /facebook\.com/i,
      /fb\.watch/i,
      /youtube\.com/i,
      /youtu\.be/i,
    ];

    return socialMediaPatterns.some((pattern) => pattern.test(url));
  }, []);

  const checkClipboard = useCallback(async () => {
    try {
      const text = await Clipboard.getStringAsync();
      if (text && isValidSocialMediaUrl(text)) {
        onLinkDetected(text);
      }
    } catch (error) {
      console.error("Failed to check clipboard:", error);
    }
  }, [isValidSocialMediaUrl, onLinkDetected]);

  useEffect(() => {
    // Check clipboard when component mounts
    checkClipboard();

    // Optional: Set up interval to check clipboard periodically
    // const interval = setInterval(checkClipboard, 5000);
    // return () => clearInterval(interval);
  }, [checkClipboard]);

  return { checkClipboard };
}
