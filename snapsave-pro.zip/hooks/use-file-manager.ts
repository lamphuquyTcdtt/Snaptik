import { useCallback } from "react";
import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";
import * as Sharing from "expo-sharing";
import * as Haptics from "expo-haptics";

export function useFileManager() {
  /**
   * Download file from URL and save to device
   */
  const downloadFile = useCallback(
    async (downloadUrl: string, fileName: string, fileType: "video" | "image") => {
      try {
        const fileUri = `${FileSystem.documentDirectory}${fileName}`;

        // Download file
        const result = await FileSystem.downloadAsync(downloadUrl, fileUri);

        if (result.status === 200) {
          // Save to media library
          await saveToMediaLibrary(result.uri, fileType);
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          return result.uri;
        } else {
          throw new Error("Download failed");
        }
      } catch (error) {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        throw error;
      }
    },
    []
  );

  /**
   * Save file to media library (Photos/Videos app)
   */
  const saveToMediaLibrary = useCallback(
    async (fileUri: string, fileType: "video" | "image") => {
      try {
        // Request permissions
        const { status } = await MediaLibrary.requestPermissionsAsync();
        if (status !== "granted") {
          throw new Error("Media library permission denied");
        }

        // Save to media library
        const asset = await MediaLibrary.createAssetAsync(fileUri);
        await MediaLibrary.createAlbumAsync("SnapSave Pro", asset, false);

        return asset;
      } catch (error) {
        console.error("Failed to save to media library:", error);
        throw error;
      }
    },
    []
  );

  /**
   * Share file with other apps
   */
  const shareFile = useCallback(async (fileUri: string, fileName: string) => {
    try {
      const isAvailable = await Sharing.isAvailableAsync();
      if (!isAvailable) {
        throw new Error("Sharing is not available on this platform");
      }

      await Sharing.shareAsync(fileUri, {
        mimeType: fileName.endsWith(".mp4") ? "video/mp4" : "image/*",
        dialogTitle: `Share ${fileName}`,
        UTI: fileName.endsWith(".mp4") ? "com.apple.quicktime-movie" : "public.image",
      });

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Failed to share file:", error);
      throw error;
    }
  }, []);

  /**
   * Delete file from device
   */
  const deleteFile = useCallback(async (fileUri: string) => {
    try {
      const fileInfo = await FileSystem.getInfoAsync(fileUri);
      if (fileInfo.exists) {
        await FileSystem.deleteAsync(fileUri);
      }
    } catch (error) {
      console.error("Failed to delete file:", error);
      throw error;
    }
  }, []);

  /**
   * Get file info
   */
  const getFileInfo = useCallback(async (fileUri: string) => {
    try {
      const info = await FileSystem.getInfoAsync(fileUri);
      return info;
    } catch (error) {
      console.error("Failed to get file info:", error);
      throw error;
    }
  }, []);

  return {
    downloadFile,
    saveToMediaLibrary,
    shareFile,
    deleteFile,
    getFileInfo,
  };
}
