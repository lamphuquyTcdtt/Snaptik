import { useCallback, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface HistoryEntry {
  id: string;
  url: string;
  platform: string;
  title: string;
  timestamp: number;
  quality: "sd" | "hd" | "full_hd" | "4k";
  status: "success" | "failed";
  errorMessage?: string;
}

const HISTORY_KEY = "@snapsave_download_history";
const PRIVATE_MODE_KEY = "@snapsave_private_mode";
const AUTO_DELETE_HISTORY_KEY = "@snapsave_auto_delete_history";

/**
 * Hook quản lý lịch sử tải và chế độ ẩn
 */
export function useDownloadHistory() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [privateMode, setPrivateMode] = useState(false);
  const [autoDeleteHistory, setAutoDeleteHistory] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Load lịch sử khi component mount
  useEffect(() => {
    loadHistory();
  }, []);

  /**
   * Load lịch sử từ AsyncStorage
   */
  const loadHistory = useCallback(async () => {
    try {
      setIsLoading(true);
      const [historyData, privateModeData, autoDeleteData] = await Promise.all([
        AsyncStorage.getItem(HISTORY_KEY),
        AsyncStorage.getItem(PRIVATE_MODE_KEY),
        AsyncStorage.getItem(AUTO_DELETE_HISTORY_KEY),
      ]);

      if (historyData) {
        setHistory(JSON.parse(historyData));
      }

      if (privateModeData) {
        setPrivateMode(JSON.parse(privateModeData));
      }

      if (autoDeleteData) {
        setAutoDeleteHistory(JSON.parse(autoDeleteData));
      }
    } catch (error) {
      console.error("Failed to load history:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Thêm entry vào lịch sử
   */
  const addEntry = useCallback(
    async (entry: Omit<HistoryEntry, "id" | "timestamp">) => {
      try {
        // Không lưu lịch sử nếu ở chế độ ẩn
        if (privateMode) {
          return;
        }

        const newEntry: HistoryEntry = {
          ...entry,
          id: `${Date.now()}-${Math.random()}`,
          timestamp: Date.now(),
        };

        const updatedHistory = [newEntry, ...history];
        setHistory(updatedHistory);
        await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
      } catch (error) {
        console.error("Failed to add history entry:", error);
      }
    },
    [history, privateMode]
  );

  /**
   * Xóa entry từ lịch sử
   */
  const deleteEntry = useCallback(
    async (id: string) => {
      try {
        const updatedHistory = history.filter((entry) => entry.id !== id);
        setHistory(updatedHistory);
        await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
      } catch (error) {
        console.error("Failed to delete history entry:", error);
      }
    },
    [history]
  );

  /**
   * Xóa tất cả lịch sử
   */
  const clearHistory = useCallback(async () => {
    try {
      setHistory([]);
      await AsyncStorage.removeItem(HISTORY_KEY);
    } catch (error) {
      console.error("Failed to clear history:", error);
    }
  }, []);

  /**
   * Xóa lịch sử cũ (hơn 30 ngày)
   */
  const deleteOldHistory = useCallback(async () => {
    try {
      const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
      const updatedHistory = history.filter((entry) => entry.timestamp > thirtyDaysAgo);
      setHistory(updatedHistory);
      await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (error) {
      console.error("Failed to delete old history:", error);
    }
  }, [history]);

  /**
   * Bật/tắt chế độ ẩn
   */
  const togglePrivateMode = useCallback(async (enabled: boolean) => {
    try {
      setPrivateMode(enabled);
      await AsyncStorage.setItem(PRIVATE_MODE_KEY, JSON.stringify(enabled));

      // Nếu bật chế độ ẩn, xóa lịch sử hiện tại
      if (enabled) {
        setHistory([]);
        await AsyncStorage.removeItem(HISTORY_KEY);
      }
    } catch (error) {
      console.error("Failed to toggle private mode:", error);
    }
  }, []);

  /**
   * Bật/tắt tự động xóa lịch sử
   */
  const toggleAutoDeleteHistory = useCallback(async (enabled: boolean) => {
    try {
      setAutoDeleteHistory(enabled);
      await AsyncStorage.setItem(AUTO_DELETE_HISTORY_KEY, JSON.stringify(enabled));
    } catch (error) {
      console.error("Failed to toggle auto delete history:", error);
    }
  }, []);

  /**
   * Lấy lịch sử theo nền tảng
   */
  const getHistoryByPlatform = useCallback(
    (platform: string) => {
      return history.filter((entry) => entry.platform === platform);
    },
    [history]
  );

  /**
   * Lấy lịch sử thành công
   */
  const getSuccessfulHistory = useCallback(() => {
    return history.filter((entry) => entry.status === "success");
  }, [history]);

  /**
   * Lấy lịch sử thất bại
   */
  const getFailedHistory = useCallback(() => {
    return history.filter((entry) => entry.status === "failed");
  }, [history]);

  /**
   * Tìm kiếm lịch sử
   */
  const searchHistory = useCallback(
    (query: string) => {
      const lowerQuery = query.toLowerCase();
      return history.filter(
        (entry) =>
          entry.title.toLowerCase().includes(lowerQuery) ||
          entry.url.toLowerCase().includes(lowerQuery) ||
          entry.platform.toLowerCase().includes(lowerQuery)
      );
    },
    [history]
  );

  /**
   * Lấy thống kê lịch sử
   */
  const getStatistics = useCallback(() => {
    const total = history.length;
    const successful = history.filter((e) => e.status === "success").length;
    const failed = history.filter((e) => e.status === "failed").length;
    const byPlatform = history.reduce(
      (acc, entry) => {
        acc[entry.platform] = (acc[entry.platform] || 0) + 1;
        return acc;
      },
      {} as Record<string, number>
    );

    return {
      total,
      successful,
      failed,
      successRate: total > 0 ? Math.round((successful / total) * 100) : 0,
      byPlatform,
    };
  }, [history]);

  return {
    history,
    privateMode,
    autoDeleteHistory,
    isLoading,
    addEntry,
    deleteEntry,
    clearHistory,
    deleteOldHistory,
    togglePrivateMode,
    toggleAutoDeleteHistory,
    getHistoryByPlatform,
    getSuccessfulHistory,
    getFailedHistory,
    searchHistory,
    getStatistics,
  };
}
