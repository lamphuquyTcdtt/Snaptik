import { useCallback, useState } from "react";

export interface MediaPreview {
  type: "video" | "image" | "album";
  title: string;
  description?: string;
  thumbnail?: string;
  duration?: number; // giây
  quality: string[];
  size?: number; // bytes
  author?: string;
  platform: string;
  url: string;
  items?: MediaItem[]; // Cho album
}

export interface MediaItem {
  id: string;
  type: "video" | "image";
  thumbnail: string;
  duration?: number;
  selected: boolean;
}

/**
 * Hook preview media trước khi tải
 */
export function useMediaPreview() {
  const [preview, setPreview] = useState<MediaPreview | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Tạo preview từ URL
   */
  const createPreview = useCallback(async (url: string, platform: string) => {
    try {
      setIsLoading(true);
      setError(null);

      // Gọi API để lấy metadata
      const response = await fetch("/api/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, platform }),
      });

      if (!response.ok) {
        throw new Error("Failed to create preview");
      }

      const data = await response.json();
      setPreview(data);
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Cập nhật lựa chọn item trong album
   */
  const toggleItemSelection = useCallback(
    (itemId: string) => {
      if (!preview || !preview.items) return;

      const updatedItems = preview.items.map((item) =>
        item.id === itemId ? { ...item, selected: !item.selected } : item
      );

      setPreview({
        ...preview,
        items: updatedItems,
      });
    },
    [preview]
  );

  /**
   * Chọn tất cả item
   */
  const selectAllItems = useCallback(() => {
    if (!preview || !preview.items) return;

    const updatedItems = preview.items.map((item) => ({
      ...item,
      selected: true,
    }));

    setPreview({
      ...preview,
      items: updatedItems,
    });
  }, [preview]);

  /**
   * Bỏ chọn tất cả item
   */
  const deselectAllItems = useCallback(() => {
    if (!preview || !preview.items) return;

    const updatedItems = preview.items.map((item) => ({
      ...item,
      selected: false,
    }));

    setPreview({
      ...preview,
      items: updatedItems,
    });
  }, [preview]);

  /**
   * Lấy danh sách item được chọn
   */
  const getSelectedItems = useCallback(() => {
    if (!preview || !preview.items) return [];
    return preview.items.filter((item) => item.selected);
  }, [preview]);

  /**
   * Định dạng kích thước file
   */
  const formatFileSize = useCallback((bytes?: number): string => {
    if (!bytes) return "Unknown";

    const units = ["B", "KB", "MB", "GB"];
    let size = bytes;
    let unitIndex = 0;

    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }

    return `${size.toFixed(2)} ${units[unitIndex]}`;
  }, []);

  /**
   * Định dạng thời lượng video
   */
  const formatDuration = useCallback((seconds?: number): string => {
    if (!seconds) return "Unknown";

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    }

    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  }, []);

  /**
   * Clear preview
   */
  const clearPreview = useCallback(() => {
    setPreview(null);
    setError(null);
  }, []);

  return {
    preview,
    isLoading,
    error,
    createPreview,
    toggleItemSelection,
    selectAllItems,
    deselectAllItems,
    getSelectedItems,
    formatFileSize,
    formatDuration,
    clearPreview,
  };
}
