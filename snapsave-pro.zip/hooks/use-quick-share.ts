import { useCallback } from "react";
import * as Sharing from "expo-sharing";
import * as Linking from "expo-linking";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { Alert } from "react-native";

export enum ShareTarget {
  ZALO = "zalo",
  TELEGRAM = "telegram",
  WHATSAPP = "whatsapp",
  FACEBOOK = "facebook",
  TWITTER = "twitter",
  GENERIC = "generic",
}

export interface ShareOptions {
  title: string;
  message: string;
  url?: string;
  fileUri?: string;
}

/**
 * Hook chia sẻ nhanh sang các ứng dụng khác
 */
export function useQuickShare() {
  /**
   * Chia sẻ sang Zalo
   */
  const shareToZalo = useCallback(async (options: ShareOptions) => {
    try {
      const { title, message, url } = options;
      const shareText = `${title}\n${message}${url ? `\n${url}` : ""}`;

      // Zalo deep link
      const zaloUrl = `zalo://msg?text=${encodeURIComponent(shareText)}`;

      const canOpen = await Linking.canOpenURL(zaloUrl);
      if (!canOpen) {
        Alert.alert("Zalo chưa được cài đặt", "Vui lòng cài đặt Zalo để chia sẻ");
        return false;
      }

      await Linking.openURL(zaloUrl);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share to Zalo:", error);
      return false;
    }
  }, []);

  /**
   * Chia sẻ sang Telegram
   */
  const shareToTelegram = useCallback(async (options: ShareOptions) => {
    try {
      const { title, message, url } = options;
      const shareText = `${title}\n${message}${url ? `\n${url}` : ""}`;

      // Telegram deep link
      const telegramUrl = `tg://msg?text=${encodeURIComponent(shareText)}`;

      const canOpen = await Linking.canOpenURL(telegramUrl);
      if (!canOpen) {
        Alert.alert("Telegram chưa được cài đặt", "Vui lòng cài đặt Telegram để chia sẻ");
        return false;
      }

      await Linking.openURL(telegramUrl);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share to Telegram:", error);
      return false;
    }
  }, []);

  /**
   * Chia sẻ sang WhatsApp
   */
  const shareToWhatsApp = useCallback(async (options: ShareOptions) => {
    try {
      const { title, message, url } = options;
      const shareText = `${title}\n${message}${url ? `\n${url}` : ""}`;

      // WhatsApp deep link
      const whatsappUrl = `whatsapp://send?text=${encodeURIComponent(shareText)}`;

      const canOpen = await Linking.canOpenURL(whatsappUrl);
      if (!canOpen) {
        Alert.alert("WhatsApp chưa được cài đặt", "Vui lòng cài đặt WhatsApp để chia sẻ");
        return false;
      }

      await Linking.openURL(whatsappUrl);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share to WhatsApp:", error);
      return false;
    }
  }, []);

  /**
   * Chia sẻ sang Facebook
   */
  const shareToFacebook = useCallback(async (options: ShareOptions) => {
    try {
      const { url } = options;
      if (!url) {
        Alert.alert("Lỗi", "Cần có URL để chia sẻ sang Facebook");
        return false;
      }

      // Facebook share dialog
      const facebookUrl = `fb://share/?href=${encodeURIComponent(url)}`;

      const canOpen = await Linking.canOpenURL(facebookUrl);
      if (!canOpen) {
        Alert.alert("Facebook chưa được cài đặt", "Vui lòng cài đặt Facebook để chia sẻ");
        return false;
      }

      await Linking.openURL(facebookUrl);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share to Facebook:", error);
      return false;
    }
  }, []);

  /**
   * Chia sẻ sang Twitter
   */
  const shareToTwitter = useCallback(async (options: ShareOptions) => {
    try {
      const { title, message, url } = options;
      const shareText = `${title}\n${message}${url ? `\n${url}` : ""}`;

      // Twitter share intent
      const twitterUrl = `twitter://post?message=${encodeURIComponent(shareText)}`;

      const canOpen = await Linking.canOpenURL(twitterUrl);
      if (!canOpen) {
        Alert.alert("Twitter chưa được cài đặt", "Vui lòng cài đặt Twitter để chia sẻ");
        return false;
      }

      await Linking.openURL(twitterUrl);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share to Twitter:", error);
      return false;
    }
  }, []);

  /**
   * Chia sẻ chung (dùng share sheet)
   */
  const shareGeneric = useCallback(async (options: ShareOptions) => {
    try {
      const isAvailable = await Sharing.isAvailableAsync();
      if (!isAvailable) {
        Alert.alert("Lỗi", "Chia sẻ không khả dụng trên thiết bị này");
        return false;
      }

      const { title, message, fileUri } = options;

      if (fileUri) {
        await Sharing.shareAsync(fileUri, {
          mimeType: fileUri.endsWith(".mp4") ? "video/mp4" : "image/*",
          dialogTitle: title,
        });
      } else {
        await Sharing.shareAsync("", {
          dialogTitle: title,
        });
      }

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return true;
    } catch (error) {
      console.error("Failed to share:", error);
      return false;
    }
  }, []);

  /**
   * Copy link vào clipboard
   */
  const copyToClipboard = useCallback(async (text: string, message?: string) => {
    try {
      await Clipboard.setStringAsync(text);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Thành công", message || "Đã sao chép vào clipboard");
      return true;
    } catch (error) {
      console.error("Failed to copy to clipboard:", error);
      Alert.alert("Lỗi", "Không thể sao chép");
      return false;
    }
  }, []);

  /**
   * Chia sẻ tới target cụ thể
   */
  const shareToTarget = useCallback(
    async (target: ShareTarget, options: ShareOptions): Promise<boolean> => {
      switch (target) {
        case ShareTarget.ZALO:
          return shareToZalo(options);
        case ShareTarget.TELEGRAM:
          return shareToTelegram(options);
        case ShareTarget.WHATSAPP:
          return shareToWhatsApp(options);
        case ShareTarget.FACEBOOK:
          return shareToFacebook(options);
        case ShareTarget.TWITTER:
          return shareToTwitter(options);
        case ShareTarget.GENERIC:
          return shareGeneric(options);
        default:
          return false;
      }
    },
    [shareToZalo, shareToTelegram, shareToWhatsApp, shareToFacebook, shareToTwitter, shareGeneric]
  );

  /**
   * Lấy danh sách các ứng dụng chia sẻ khả dụng
   */
  const getAvailableTargets = useCallback(async (): Promise<ShareTarget[]> => {
    const available: ShareTarget[] = [];

    // Kiểm tra từng ứng dụng
    const targets = [
      { target: ShareTarget.ZALO, url: "zalo://" },
      { target: ShareTarget.TELEGRAM, url: "tg://" },
      { target: ShareTarget.WHATSAPP, url: "whatsapp://" },
      { target: ShareTarget.FACEBOOK, url: "fb://" },
      { target: ShareTarget.TWITTER, url: "twitter://" },
    ];

    for (const { target, url } of targets) {
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        available.push(target);
      }
    }

    return available;
  }, []);

  return {
    shareToZalo,
    shareToTelegram,
    shareToWhatsApp,
    shareToFacebook,
    shareToTwitter,
    shareGeneric,
    shareToTarget,
    copyToClipboard,
    getAvailableTargets,
  };
}
