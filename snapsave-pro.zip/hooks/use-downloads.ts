import { useState, useCallback, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface Download {
  id: string;
  url: string;
  platform: "tiktok" | "instagram" | "facebook" | "youtube";
  title: string;
  thumbnail?: string;
  type: "video" | "image";
  duration?: number;
  size?: number;
  quality: "sd" | "hd" | "full_hd";
  downloadUrl: string;
  timestamp: number;
}

const STORAGE_KEY = "@snapsave_downloads";

export function useDownloads() {
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load downloads from AsyncStorage on mount
  useEffect(() => {
    loadDownloads();
  }, []);

  const loadDownloads = useCallback(async () => {
    try {
      setIsLoading(true);
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        setDownloads(parsed);
      }
    } catch (error) {
      console.error("Failed to load downloads:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const addDownload = useCallback(
    async (download: Omit<Download, "id" | "timestamp">) => {
      try {
        const newDownload: Download = {
          ...download,
          id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          timestamp: Date.now(),
        };

        const updated = [newDownload, ...downloads];
        setDownloads(updated);
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        return newDownload;
      } catch (error) {
        console.error("Failed to add download:", error);
        throw error;
      }
    },
    [downloads]
  );

  const removeDownload = useCallback(
    async (id: string) => {
      try {
        const updated = downloads.filter((d) => d.id !== id);
        setDownloads(updated);
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Failed to remove download:", error);
        throw error;
      }
    },
    [downloads]
  );

  const clearAllDownloads = useCallback(async () => {
    try {
      setDownloads([]);
      await AsyncStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error("Failed to clear downloads:", error);
      throw error;
    }
  }, []);

  return {
    downloads,
    isLoading,
    addDownload,
    removeDownload,
    clearAllDownloads,
    loadDownloads,
  };
}
