# SnapSave Pro v2.0 - Hướng Dẫn Nâng Cấp

## 📋 Tổng Quan Nâng Cấp

SnapSave Pro v2.0 mang đến nhiều cải tiến quan trọng:

- **Hệ thống update tự động** - API cập nhật mà không cần cập nhật app
- **Chống lỗi & ổn định** - Xử lý lỗi thông minh, retry tự động
- **Tốc độ tải nhanh** - Cache 5 phút, tải song song, ưu tiên server
- **Hỗ trợ 5 nền tảng** - Thêm X (Twitter) vào TikTok, Instagram, Facebook, YouTube
- **Preview trước tải** - Xem thông tin metadata trước khi tải
- **Lịch sử & Chế độ ẩn** - Quản lý lịch sử, Private Mode
- **Chia sẻ nhanh** - Zalo, Telegram, WhatsApp, Facebook, Twitter

---

## 🚀 Các Tính Năng Mới

### 1. Hệ Thống Update Tự Động

**File:** `server/version-manager.ts`

Quản lý phiên bản API tự động. Khi backend cập nhật, app sẽ tự động nhận biết mà không cần cập nhật từ store.

```typescript
// Kiểm tra phiên bản
const result = checkApiVersion(clientVersion);
if (result.hasUpdate) {
  // Thông báo cập nhật
}
```

### 2. Xử Lý Lỗi & Retry Thông Minh

**File:** `server/error-handler.ts`

Phát hiện 9 loại lỗi khác nhau và xử lý tự động:

- `INVALID_URL` - URL không hợp lệ
- `PRIVATE_LINK` - Bài viết riêng tư
- `DEAD_LINK` - Link đã xóa
- `UNSUPPORTED_PLATFORM` - Nền tảng không hỗ trợ
- `PLATFORM_CHANGED` - Nền tảng thay đổi cấu trúc
- `NETWORK_ERROR` - Lỗi mạng
- `TIMEOUT` - Yêu cầu vượt quá thời gian chờ
- `RATE_LIMITED` - Quá nhiều yêu cầu
- `UNKNOWN` - Lỗi không xác định

**Retry Manager** tự động thử lại với exponential backoff.

**Cache Manager** lưu link trong 5 phút để tải lại nhanh.

```typescript
// Sử dụng
const { cacheManager, retryManager } = require('./error-handler');

// Cache
cacheManager.set(url, data);
const cached = cacheManager.get(url);

// Retry
await retryManager.executeWithRetry(async () => {
  return await downloadFile(url);
});
```

### 3. Lịch Sử & Chế Độ Ẩn

**File:** `hooks/use-download-history.ts`

Quản lý lịch sử tải với các tính năng:

- Lưu lịch sử tải (platform, URL, title, status)
- **Private Mode** - Không lưu lịch sử
- Tự động xóa lịch sử cũ (>30 ngày)
- Thống kê tải (tổng, thành công, thất bại)
- Tìm kiếm lịch sử

```typescript
const {
  history,
  privateMode,
  addEntry,
  deleteEntry,
  togglePrivateMode,
  getStatistics,
} = useDownloadHistory();
```

### 4. Preview Media Trước Khi Tải

**File:** `hooks/use-media-preview.ts`

Xem thông tin chi tiết trước khi tải:

- Thumbnail
- Thời lượng video
- Kích thước file
- Tác giả
- Chất lượng có sẵn
- Album ảnh (chọn file cụ thể)

```typescript
const { preview, createPreview, toggleItemSelection } = useMediaPreview();

// Tạo preview
const previewData = await createPreview(url, platform);

// Chọn file từ album
toggleItemSelection(itemId);
```

### 5. Chia Sẻ Nhanh

**File:** `hooks/use-quick-share.ts`

Chia sẻ nhanh sang các ứng dụng:

- **Zalo** - Chia sẻ tin nhắn
- **Telegram** - Chia sẻ tin nhắn
- **WhatsApp** - Chia sẻ tin nhắn
- **Facebook** - Chia sẻ bài viết
- **Twitter** - Chia sẻ tweet
- **Copy Link** - Sao chép vào clipboard
- **Generic Share** - Chia sẻ chung

```typescript
const { shareToZalo, shareToTelegram, copyToClipboard } = useQuickShare();

// Chia sẻ
await shareToZalo({
  title: "Video Title",
  message: "Check this out!",
  fileUri: "/path/to/file",
});

// Copy link
await copyToClipboard(url, "Copied!");
```

### 6. Hỗ Trợ X (Twitter)

Thêm hỗ trợ X (Twitter) bên cạnh 4 nền tảng hiện có.

Các nền tảng được hỗ trợ:
- TikTok
- Instagram
- Facebook
- YouTube
- X (Twitter) ✨ **MỚI**

---

## 📁 Cấu Trúc File Mới

```
server/
├── version-manager.ts      # Quản lý phiên bản API
├── error-handler.ts        # Xử lý lỗi, retry, cache
└── routers.ts              # Cập nhật với endpoint preview & version

hooks/
├── use-download-history.ts # Lịch sử & Private Mode
├── use-media-preview.ts    # Preview media
└── use-quick-share.ts      # Chia sẻ nhanh

app/(tabs)/
├── history.tsx             # Màn hình Lịch Sử (MỚI)
├── index.tsx               # Màn hình Home (cập nhật)
├── settings.tsx            # Màn hình Settings
└── _layout.tsx             # Tab navigation

components/
├── preview-modal.tsx       # Modal preview (MỚI)
├── quick-share-sheet.tsx   # Bottom sheet chia sẻ (MỚI)
└── ...
```

---

## 🔧 Cách Tích Hợp

### 1. Cập Nhật Backend Routers

Thêm vào `server/routers.ts`:

```typescript
import { checkApiVersion, getCurrentVersion, getChangelog } from "./version-manager";
import { cacheManager, retryManager } from "./error-handler";

// Thêm version router
export const versionRouter = router({
  check: publicProcedure
    .input(z.object({ clientVersion: z.string() }))
    .query(({ input }) => {
      return {
        success: true,
        data: checkApiVersion(input.clientVersion),
      };
    }),
});

// Thêm preview router
export const previewRouter = router({
  fetch: publicProcedure
    .input(z.object({ url: z.string().url(), platform: z.string() }))
    .query(async ({ input }) => {
      const cached = cacheManager.get(`preview:${input.url}`);
      if (cached) return { success: true, data: cached };
      // ... fetch preview
    }),
});

// Cập nhật appRouter
export const appRouter = router({
  download: downloadRouter,
  preview: previewRouter,
  version: versionRouter,
});
```

### 2. Sử Dụng Hooks Mới Trong Component

```typescript
import { useDownloadHistory } from "@/hooks/use-download-history";
import { useMediaPreview } from "@/hooks/use-media-preview";
import { useQuickShare } from "@/hooks/use-quick-share";
import { PreviewModal } from "@/components/preview-modal";
import { QuickShareSheet } from "@/components/quick-share-sheet";

export default function HomeScreen() {
  const { addEntry } = useDownloadHistory();
  const { preview, createPreview } = useMediaPreview();
  const { shareToZalo } = useQuickShare();

  const handleDownload = async (url: string) => {
    // Tạo preview
    const previewData = await createPreview(url, platform);
    
    // Tải file
    const result = await downloadFile(url);
    
    // Lưu vào lịch sử
    await addEntry({
      url,
      platform,
      title: previewData.title,
      quality: "hd",
      status: "success",
    });
  };

  return (
    <>
      <PreviewModal
        visible={showPreview}
        preview={preview}
        onDownload={handleDownload}
      />
      <QuickShareSheet
        visible={showShare}
        title="Video Title"
        message="Check this out!"
      />
    </>
  );
}
```

---

## 📊 Thống Kê & Lịch Sử

Màn hình History hiển thị:

- **Thống kê**: Tổng tải, thành công, thất bại
- **Lịch sử chi tiết**: Platform, tiêu đề, thời gian, trạng thái
- **Private Mode**: Bật/tắt để không lưu lịch sử
- **Auto Delete**: Tự động xóa lịch sử cũ sau 30 ngày
- **Tìm kiếm**: Tìm kiếm theo tiêu đề, URL, platform

---

## 🔐 Bảo Mật & Quyền Riêng Tư

- ✅ **Không lưu link người dùng** - Chỉ lưu metadata
- ✅ **Không thu thập dữ liệu cá nhân** - Tất cả dữ liệu cục bộ
- ✅ **Private Mode** - Không lưu lịch sử
- ✅ **Cảnh báo bản quyền** - Hiển thị rõ ràng

---

## 🚀 Bước Tiếp Theo

1. **Tích hợp API thực tế** - Thay thế mock downloader
2. **Thêm tính năng PRO** - Subscription, không quảng cáo
3. **Tối ưu hiệu suất** - Compression, background download
4. **Mở rộng nền tảng** - Thêm TikTok Shop, Pinterest, v.v.

---

## 📞 Hỗ Trợ

Nếu gặp vấn đề:
1. Kiểm tra logs: `pnpm dev --verbose`
2. Xem Expo documentation
3. Liên hệ team phát triển

---

**SnapSave Pro v2.0 - Nâng cấp hoàn toàn! 🎉**
