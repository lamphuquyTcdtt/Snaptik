# SnapSave Pro - Hướng Dẫn Build APK & IPA

## Yêu Cầu Hệ Thống

### Chung
- Node.js 18+ 
- pnpm 9.12.0+
- Expo CLI

### Cho Android
- Android SDK (API level 31+)
- Android NDK
- Java Development Kit (JDK) 11+

### Cho iOS
- macOS 12+
- Xcode 14+
- CocoaPods

---

## Chuẩn Bị

### 1. Cài Đặt Dependencies

```bash
cd /home/ubuntu/snapsave-pro
pnpm install
```

### 2. Kiểm Tra Cấu Hình

```bash
pnpm check
```

---

## Build APK (Android)

### Phương Pháp 1: Sử Dụng EAS Build (Khuyến Nghị)

**Bước 1:** Cài đặt EAS CLI
```bash
npm install -g eas-cli
```

**Bước 2:** Đăng nhập vào Expo
```bash
eas login
```

**Bước 3:** Khởi tạo EAS project
```bash
eas build:configure
```

**Bước 4:** Build APK
```bash
eas build --platform android --local
```

Hoặc build trên cloud:
```bash
eas build --platform android
```

### Phương Pháp 2: Build Cục Bộ

**Bước 1:** Chuẩn bị Android SDK
```bash
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_SDK_ROOT/tools:$ANDROID_SDK_ROOT/platform-tools
```

**Bước 2:** Build APK
```bash
eas build --platform android --local
```

**Bước 3:** File APK sẽ được lưu tại:
```
./dist/snapsave-pro-*.apk
```

---

## Build IPA (iOS)

### Yêu Cầu
- Tài khoản Apple Developer ($99/năm)
- Xcode cài đặt trên macOS
- Provisioning Profile và Certificate

### Phương Pháp 1: Sử Dụng EAS Build (Khuyến Nghị)

**Bước 1:** Chuẩn bị Apple Developer Account
- Đăng nhập vào [Apple Developer](https://developer.apple.com)
- Tạo App ID cho `space.manus.snapsave.pro`
- Tạo Provisioning Profile

**Bước 2:** Build IPA
```bash
eas build --platform ios
```

**Bước 3:** Download IPA từ EAS Dashboard

### Phương Pháp 2: Build Cục Bộ (Nâng Cao)

**Bước 1:** Chuẩn bị Xcode
```bash
xcode-select --install
```

**Bước 2:** Cài đặt CocoaPods dependencies
```bash
cd ios
pod install
cd ..
```

**Bước 3:** Build IPA
```bash
eas build --platform ios --local
```

---

## Cấu Hình Trước Build

### 1. Cập Nhật Phiên Bản

Chỉnh sửa `app.config.ts`:
```typescript
const config: ExpoConfig = {
  version: "1.0.0",  // Thay đổi phiên bản tại đây
  // ...
};
```

### 2. Cập Nhật Bundle ID

Android: `space.manus.snapsave.pro`
iOS: `space.manus.snapsave.pro`

### 3. Cấu Hình Permissions

**Android** (`app.config.ts`):
```typescript
android: {
  permissions: [
    "POST_NOTIFICATIONS",
    "READ_EXTERNAL_STORAGE",
    "WRITE_EXTERNAL_STORAGE",
  ],
}
```

**iOS** (`app.config.ts`):
```typescript
ios: {
  infoPlist: {
    NSPhotoLibraryUsageDescription: "SnapSave Pro cần truy cập thư viện ảnh",
    NSPhotoLibraryAddUsageDescription: "SnapSave Pro cần lưu ảnh vào thư viện",
  },
}
```

---

## Kiểm Tra Trước Build

### 1. Kiểm Tra TypeScript
```bash
pnpm check
```

### 2. Kiểm Tra Linting
```bash
pnpm lint
```

### 3. Chạy Tests
```bash
pnpm test
```

### 4. Chạy Dev Server
```bash
pnpm dev
```

---

## Phân Phối

### Android

**Google Play Store:**
1. Tạo Google Play Developer Account ($25 một lần)
2. Tạo App Listing
3. Upload APK đã ký
4. Điền thông tin app (mô tả, ảnh chụp màn hình, v.v.)
5. Submit để review

**APK Trực Tiếp:**
- Chia sẻ file APK trực tiếp
- Người dùng có thể cài đặt từ file

### iOS

**App Store:**
1. Tạo Apple Developer Account ($99/năm)
2. Tạo App ID trên Apple Developer Portal
3. Tạo Provisioning Profile
4. Upload IPA qua App Store Connect
5. Điền thông tin app
6. Submit để review (thường 24-48 giờ)

**TestFlight:**
- Phân phối beta version cho tester
- Sử dụng App Store Connect

---

## Xử Lý Sự Cố

### APK không cài được
- Kiểm tra Android version (tối thiểu API 31)
- Xóa app cũ trước khi cài
- Kiểm tra storage còn trống

### IPA build thất bại
- Kiểm tra Xcode version
- Kiểm tra Provisioning Profile hợp lệ
- Xóa build cache: `rm -rf ios/Pods ios/Podfile.lock`

### Build quá lâu
- Kiểm tra internet connection
- Sử dụng local build thay vì cloud
- Xóa node_modules và cài lại: `pnpm install`

---

## Tối Ưu Hóa Build

### Giảm Kích Thước APK
```bash
# Trong app.config.ts
android: {
  buildArchs: ["arm64-v8a"],  // Chỉ build cho 64-bit
}
```

### Bật Proguard (Android)
```bash
# Trong app.config.ts
android: {
  enableProguard: true,
}
```

---

## Tài Liệu Tham Khảo

- [Expo Documentation](https://docs.expo.dev)
- [EAS Build Guide](https://docs.expo.dev/build/introduction/)
- [React Native Documentation](https://reactnative.dev)
- [Apple Developer Documentation](https://developer.apple.com/documentation)
- [Google Play Developer Documentation](https://developer.android.com)

---

## Hỗ Trợ

Nếu gặp vấn đề:
1. Kiểm tra logs: `eas build --platform android --local --verbose`
2. Xem Expo documentation
3. Tìm kiếm issue trên GitHub
4. Liên hệ Expo support

---

**Chúc bạn build thành công! 🚀**
