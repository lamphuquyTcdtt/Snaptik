# SnapSave Pro - Ứng Dụng Tải Video & Ảnh Không Logo

**SnapSave Pro** là ứng dụng di động hiện đại cho phép bạn tải video và ảnh chất lượng cao không logo từ các nền tảng mạng xã hội phổ biến.

---

## 🎯 Tính Năng Chính

### ✅ Hỗ Trợ Nền Tảng
- **TikTok** - Tải video TikTok không watermark
- **Instagram** - Tải ảnh, video, Reels chất lượng gốc
- **Facebook** - Tải video Facebook HD
- **YouTube** - Tải video YouTube công khai

### 📥 Chức Năng Tải
- Dán link và tải ngay
- Chọn chất lượng: SD / HD / Full HD
- Tải nhiều video/ảnh trong cùng bài viết
- Tải nhanh, ổn định

### 🎨 Giao Diện
- Thiết kế hiện đại, tối giản
- Dark Mode hỗ trợ đầy đủ
- Màu chủ đạo: Xanh dương - Trắng
- Một tay dễ dùng trên điện thoại

### 💾 Quản Lý Tệp
- Danh sách tệp đã tải
- Chia sẻ video/ảnh với ứng dụng khác
- Xóa tệp không cần thiết
- Lưu vào thư viện máy tự động

### 🔐 Bảo Mật & Quyền Riêng Tư
- Không yêu cầu đăng nhập
- Không lưu dữ liệu cá nhân
- Không theo dõi hoạt động người dùng
- Cảnh báo bản quyền rõ ràng

---

## 🚀 Bắt Đầu Nhanh

### Cài Đặt

```bash
# Clone hoặc tải dự án
cd snapsave-pro

# Cài đặt dependencies
pnpm install

# Chạy dev server
pnpm dev
```

### Chạy Trên Thiết Bị

**iOS (macOS):**
```bash
pnpm ios
```

**Android:**
```bash
pnpm android
```

**Web:**
```bash
pnpm dev
# Mở http://localhost:8081
```

---

## 📱 Cấu Trúc Dự Án

```
snapsave-pro/
├── app/
│   ├── (tabs)/
│   │   ├── index.tsx          # Màn hình Home (tải video/ảnh)
│   │   ├── settings.tsx       # Màn hình Settings
│   │   └── _layout.tsx        # Tab navigation
│   ├── _layout.tsx            # Root layout
│   └── oauth/                 # Auth callback
├── components/
│   ├── input-link.tsx         # Component nhập URL
│   ├── download-button.tsx    # Nút tải xuống
│   ├── download-card.tsx      # Card hiển thị tệp
│   └── screen-container.tsx   # SafeArea wrapper
├── hooks/
│   ├── use-downloads.ts       # Quản lý danh sách tệp
│   ├── use-file-manager.ts    # Lưu/chia sẻ file
│   └── use-clipboard-monitor.ts # Theo dõi clipboard
├── server/
│   ├── routers.ts             # tRPC API endpoints
│   ├── db.ts                  # Database queries
│   └── storage.ts             # S3 storage helpers
├── theme.config.js            # Cấu hình màu sắc
├── app.config.ts              # Cấu hình Expo
└── BUILD_GUIDE.md             # Hướng dẫn build APK/IPA
```

---

## 🛠️ Công Nghệ Sử Dụng

| Công Nghệ | Phiên Bản | Mục Đích |
|-----------|----------|---------|
| React Native | 0.81 | Framework UI di động |
| Expo | 54 | Platform phát triển |
| React | 19 | UI library |
| TypeScript | 5.9 | Type safety |
| NativeWind | 4 | Tailwind CSS cho RN |
| tRPC | 11.7 | API type-safe |
| Zod | 4.2 | Schema validation |
| Express | 4.22 | Backend server |
| MySQL | - | Database |

---

## 📋 Hướng Dẫn Sử Dụng

### 1. Tải Video/Ảnh

**Bước 1:** Mở ứng dụng SnapSave Pro

**Bước 2:** Dán link từ TikTok, Instagram, Facebook, hoặc YouTube
- Sao chép link từ ứng dụng mạng xã hội
- Dán vào ô input hoặc nhấn nút "Paste"

**Bước 3:** Chọn chất lượng (nếu là video)
- SD: 480p (file nhỏ)
- HD: 720p (cân bằng)
- Full HD: 1080p (chất lượng cao)

**Bước 4:** Nhấn "Tải Xuống"
- Ứng dụng sẽ xử lý link
- Tệp sẽ được lưu vào thư viện máy
- Thông báo thành công sẽ hiển thị

### 2. Quản Lý Tệp Đã Tải

- **Xem danh sách:** Danh sách tệp hiển thị trên màn hình Home
- **Chia sẻ:** Nhấn nút "Share" để chia sẻ với ứng dụng khác
- **Xóa:** Nhấn nút "Delete" để xóa tệp

### 3. Cài Đặt

**Dark Mode:**
- Vào Settings → Dark Mode
- Bật/tắt theo ý thích

**Quản Lý Dữ Liệu:**
- Xem số lượng tệp đã tải
- Xóa tất cả dữ liệu nếu cần

---

## ⚙️ Cấu Hình Backend API

### Endpoint Chính

**GET `/api/download.health`**
- Kiểm tra trạng thái API

**POST `/api/download.fetch`**
- Tải video/ảnh từ URL
- Input: `{ url: string, quality: "sd" | "hd" | "full_hd" }`
- Output: `{ success: boolean, data: {...}, error?: string }`

**GET `/api/download.validateUrl`**
- Kiểm tra URL có hợp lệ
- Input: `{ url: string }`
- Output: `{ valid: boolean, platform?: string }`

### Ví Dụ API Call

```typescript
// Frontend
import { trpc } from "@/lib/trpc";

const downloadMutation = trpc.download.fetch.useMutation({
  onSuccess: (result) => {
    if (result.success) {
      console.log("Download successful:", result.data);
    }
  },
});

await downloadMutation.mutateAsync({
  url: "https://www.tiktok.com/@user/video/123456",
  quality: "hd",
});
```

---

## 🔧 Phát Triển

### Thêm Nền Tảng Mới

**1. Cập nhật `server/routers.ts`:**
```typescript
async function downloadFromNewPlatform(url: string, quality: string) {
  // Implement download logic
  return {
    type: "video",
    platform: "newplatform",
    title: "...",
    // ...
  };
}
```

**2. Thêm vào switch statement:**
```typescript
case "newplatform":
  result = await downloadFromNewPlatform(url, quality);
  break;
```

**3. Cập nhật `detectPlatform` function:**
```typescript
if (url.includes("newplatform.com")) return "newplatform";
```

### Tùy Chỉnh Giao Diện

**Màu sắc:** Chỉnh sửa `theme.config.js`
```javascript
const themeColors = {
  primary: { light: '#0A7EA4', dark: '#0A9FD9' },
  // ...
};
```

**Fonts:** Thêm font vào `app/_layout.tsx`
```typescript
const [fontsLoaded] = useFonts({
  "custom-font": require("./assets/fonts/custom.ttf"),
});
```

---

## 📦 Build & Deploy

Xem [BUILD_GUIDE.md](./BUILD_GUIDE.md) để hướng dẫn chi tiết:
- Build APK cho Android
- Build IPA cho iOS
- Phân phối trên Google Play & App Store

---

## 🐛 Xử Lý Sự Cố

### Tải thất bại
- Kiểm tra kết nối internet
- Đảm bảo URL hợp lệ
- Thử URL khác từ cùng nền tảng

### Ứng dụng bị crash
- Xóa cache: `pnpm clean`
- Cài lại dependencies: `pnpm install`
- Kiểm tra logs: `pnpm dev --verbose`

### Không thể lưu file
- Kiểm tra quyền truy cập file
- Đảm bảo storage còn trống
- Thử xóa dữ liệu cũ

---

## 📄 Điều Khoản & Chính Sách

### Cảnh Báo Bản Quyền
⚠️ **Chỉ tải nội dung mà bạn có quyền sử dụng.** SnapSave Pro không chịu trách nhiệm về bất kỳ vi phạm bản quyền nào.

### Quyền Riêng Tư
- Ứng dụng không lưu trữ dữ liệu cá nhân
- Không theo dõi hoạt động người dùng
- Tất cả dữ liệu được lưu cục bộ trên thiết bị

---

## 🤝 Đóng Góp

Chúng tôi hoan nghênh các đóng góp! Vui lòng:
1. Fork dự án
2. Tạo branch mới: `git checkout -b feature/your-feature`
3. Commit thay đổi: `git commit -m "Add feature"`
4. Push lên: `git push origin feature/your-feature`
5. Tạo Pull Request

---

## 📞 Hỗ Trợ

- 📧 Email: support@snapsave.pro
- 🐛 Report bugs: [GitHub Issues](https://github.com/snapsave/snapsave-pro/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/snapsave/snapsave-pro/discussions)

---

## 📄 Giấy Phép

MIT License - Xem [LICENSE](./LICENSE) để chi tiết

---

## 🙏 Cảm Ơn

Cảm ơn tất cả những người đã hỗ trợ dự án này!

---

**SnapSave Pro v1.0.0** - Tải video & ảnh dễ dàng, nhanh chóng, an toàn 🚀
