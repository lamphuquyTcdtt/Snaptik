/**
 * Error Handler - Xử lý lỗi, retry, và caching
 */

export enum ErrorType {
  INVALID_URL = "INVALID_URL",
  PRIVATE_LINK = "PRIVATE_LINK",
  DEAD_LINK = "DEAD_LINK",
  UNSUPPORTED_PLATFORM = "UNSUPPORTED_PLATFORM",
  PLATFORM_CHANGED = "PLATFORM_CHANGED",
  NETWORK_ERROR = "NETWORK_ERROR",
  TIMEOUT = "TIMEOUT",
  RATE_LIMITED = "RATE_LIMITED",
  UNKNOWN = "UNKNOWN",
}

export interface DownloadError {
  type: ErrorType;
  message: string;
  userMessage: string;
  retryable: boolean;
  retryAfter?: number; // milliseconds
  suggestion?: string;
}

export interface CacheEntry {
  url: string;
  data: any;
  timestamp: number;
  ttl: number; // milliseconds
}

/**
 * Lỗi cụ thể và thông điệp cho người dùng
 */
const ERROR_MESSAGES: Record<ErrorType, { message: string; userMessage: string; retryable: boolean }> = {
  [ErrorType.INVALID_URL]: {
    message: "URL không hợp lệ",
    userMessage: "Link không hợp lệ. Vui lòng kiểm tra lại link.",
    retryable: false,
  },
  [ErrorType.PRIVATE_LINK]: {
    message: "Bài viết là riêng tư",
    userMessage: "Bài viết này là riêng tư. Bạn không có quyền truy cập.",
    retryable: false,
  },
  [ErrorType.DEAD_LINK]: {
    message: "Link đã bị xóa hoặc hết hạn",
    userMessage: "Bài viết này đã bị xóa hoặc không còn tồn tại.",
    retryable: false,
  },
  [ErrorType.UNSUPPORTED_PLATFORM]: {
    message: "Nền tảng không được hỗ trợ",
    userMessage: "Nền tảng này chưa được hỗ trợ. Vui lòng thử nền tảng khác.",
    retryable: false,
  },
  [ErrorType.PLATFORM_CHANGED]: {
    message: "Nền tảng đã thay đổi cấu trúc",
    userMessage: "Nền tảng vừa cập nhật. Vui lòng thử lại sau vài phút.",
    retryable: true,
  },
  [ErrorType.NETWORK_ERROR]: {
    message: "Lỗi kết nối mạng",
    userMessage: "Mạng của bạn yếu hoặc bị gián đoạn. Vui lòng kiểm tra kết nối.",
    retryable: true,
  },
  [ErrorType.TIMEOUT]: {
    message: "Yêu cầu vượt quá thời gian chờ",
    userMessage: "Tải quá lâu. Vui lòng thử lại hoặc kiểm tra kết nối mạng.",
    retryable: true,
  },
  [ErrorType.RATE_LIMITED]: {
    message: "Quá nhiều yêu cầu",
    userMessage: "Bạn đã gửi quá nhiều yêu cầu. Vui lòng chờ vài phút rồi thử lại.",
    retryable: true,
  },
  [ErrorType.UNKNOWN]: {
    message: "Lỗi không xác định",
    userMessage: "Đã xảy ra lỗi không xác định. Vui lòng thử lại sau.",
    retryable: true,
  },
};

/**
 * Tạo đối tượng lỗi
 */
export function createError(
  type: ErrorType,
  customMessage?: string
): DownloadError {
  const errorInfo = ERROR_MESSAGES[type];
  const retryAfter =
    type === ErrorType.RATE_LIMITED ? 60000 : type === ErrorType.PLATFORM_CHANGED ? 300000 : undefined;

  return {
    type,
    message: customMessage || errorInfo.message,
    userMessage: errorInfo.userMessage,
    retryable: errorInfo.retryable,
    retryAfter,
    suggestion: getSuggestion(type),
  };
}

/**
 * Lấy gợi ý cho từng loại lỗi
 */
function getSuggestion(type: ErrorType): string | undefined {
  const suggestions: Record<ErrorType, string> = {
    [ErrorType.INVALID_URL]: "Sao chép link trực tiếp từ ứng dụng mạng xã hội",
    [ErrorType.PRIVATE_LINK]: "Yêu cầu chủ sở hữu công khai bài viết",
    [ErrorType.DEAD_LINK]: "Bài viết không còn tồn tại",
    [ErrorType.UNSUPPORTED_PLATFORM]: "Kiểm tra danh sách nền tảng được hỗ trợ",
    [ErrorType.PLATFORM_CHANGED]: "Hệ thống đang cập nhật. Vui lòng thử lại sau",
    [ErrorType.NETWORK_ERROR]: "Kiểm tra kết nối internet của bạn",
    [ErrorType.TIMEOUT]: "Thử lại hoặc chọn chất lượng thấp hơn",
    [ErrorType.RATE_LIMITED]: "Chờ vài phút rồi thử lại",
    [ErrorType.UNKNOWN]: "Liên hệ hỗ trợ nếu vấn đề tiếp tục",
  };

  return suggestions[type];
}

/**
 * Phát hiện loại lỗi từ exception
 */
export function detectErrorType(error: any): ErrorType {
  const message = error?.message?.toLowerCase() || "";
  const statusCode = error?.statusCode || error?.status;

  // Kiểm tra status code
  if (statusCode === 404) return ErrorType.DEAD_LINK;
  if (statusCode === 403) return ErrorType.PRIVATE_LINK;
  if (statusCode === 429) return ErrorType.RATE_LIMITED;
  if (statusCode === 408 || statusCode === 504) return ErrorType.TIMEOUT;

  // Kiểm tra thông điệp lỗi
  if (message.includes("invalid") || message.includes("malformed")) return ErrorType.INVALID_URL;
  if (message.includes("private") || message.includes("permission")) return ErrorType.PRIVATE_LINK;
  if (message.includes("not found") || message.includes("deleted")) return ErrorType.DEAD_LINK;
  if (message.includes("timeout") || message.includes("timed out")) return ErrorType.TIMEOUT;
  if (message.includes("network") || message.includes("econnrefused")) return ErrorType.NETWORK_ERROR;
  if (message.includes("rate limit")) return ErrorType.RATE_LIMITED;

  return ErrorType.UNKNOWN;
}

/**
 * Cache Manager - Lưu cache link trong 5 phút
 */
export class CacheManager {
  private cache: Map<string, CacheEntry> = new Map();
  private readonly DEFAULT_TTL = 5 * 60 * 1000; // 5 phút

  /**
   * Lưu vào cache
   */
  set(url: string, data: any, ttl: number = this.DEFAULT_TTL): void {
    this.cache.set(url, {
      url,
      data,
      timestamp: Date.now(),
      ttl,
    });
  }

  /**
   * Lấy từ cache
   */
  get(url: string): any | null {
    const entry = this.cache.get(url);

    if (!entry) return null;

    // Kiểm tra xem cache đã hết hạn chưa
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(url);
      return null;
    }

    return entry.data;
  }

  /**
   * Xóa cache
   */
  delete(url: string): void {
    this.cache.delete(url);
  }

  /**
   * Xóa tất cả cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Lấy kích thước cache
   */
  size(): number {
    return this.cache.size;
  }

  /**
   * Dọn dẹp cache hết hạn
   */
  cleanup(): void {
    const now = Date.now();
    for (const [url, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(url);
      }
    }
  }
}

/**
 * Retry Manager - Quản lý retry tự động
 */
export class RetryManager {
  private readonly maxRetries = 3;
  private readonly baseDelay = 1000; // 1 giây
  private readonly maxDelay = 30000; // 30 giây

  /**
   * Thực hiện retry với exponential backoff
   */
  async executeWithRetry<T>(
    fn: () => Promise<T>,
    onRetry?: (attempt: number, error: Error) => void
  ): Promise<T> {
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error as Error;

        // Không retry nếu là lỗi không thể retry
        const errorType = detectErrorType(error);
        if (!ERROR_MESSAGES[errorType]?.retryable) {
          throw error;
        }

        if (attempt < this.maxRetries) {
          const delay = this.calculateDelay(attempt);
          onRetry?.(attempt, lastError);
          await this.sleep(delay);
        }
      }
    }

    throw lastError;
  }

  /**
   * Tính toán độ trễ với exponential backoff
   */
  private calculateDelay(attempt: number): number {
    const delay = this.baseDelay * Math.pow(2, attempt - 1);
    return Math.min(delay, this.maxDelay);
  }

  /**
   * Sleep function
   */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// Export singleton instances
export const cacheManager = new CacheManager();
export const retryManager = new RetryManager();
