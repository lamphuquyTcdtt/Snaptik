import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Download router for social media content
  download: router({
    // Health check
    health: publicProcedure.query(() => ({
      status: "ok",
      message: "SnapSave Pro API is running",
    })),

    // Main download endpoint
    fetch: publicProcedure
      .input(z.object({
        url: z.string().url("Invalid URL"),
        quality: z.enum(["sd", "hd", "full_hd"]).default("hd"),
      }))
      .mutation(async ({ input }) => {
        try {
          const { url, quality } = input;
          const platform = detectPlatform(url);

          if (!isValidPlatform(platform)) {
            return {
              success: false,
              error: "Platform not supported. Supported: TikTok, Instagram, Facebook, YouTube",
            };
          }

          let result;

          switch (platform) {
            case "tiktok":
              result = await downloadFromTikTok(url, quality);
              break;
            case "instagram":
              result = await downloadFromInstagram(url, quality);
              break;
            case "facebook":
              result = await downloadFromFacebook(url, quality);
              break;
            case "youtube":
              result = await downloadFromYouTube(url, quality);
              break;
            default:
              throw new Error("Unknown platform");
          }

          return {
            success: true,
            data: result,
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            success: false,
            error: errorMessage,
          };
        }
      }),

    // Validate URL
    validateUrl: publicProcedure
      .input(z.object({ url: z.string() }))
      .query(({ input }) => {
        const platform = detectPlatform(input.url);
        return {
          valid: isValidPlatform(platform),
          platform: isValidPlatform(platform) ? platform : null,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;

/**
 * Helper Functions for SnapSave Pro Download Router
 */

/**
 * Detect platform from URL
 */
function detectPlatform(url: string): string {
  if (url.includes("tiktok.com") || url.includes("vm.tiktok.com")) return "tiktok";
  if (url.includes("instagram.com") || url.includes("instagr.am")) return "instagram";
  if (url.includes("facebook.com") || url.includes("fb.watch")) return "facebook";
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  return "unknown";
}

/**
 * Validate platform support
 */
function isValidPlatform(platform: string): boolean {
  return ["tiktok", "instagram", "facebook", "youtube"].includes(platform);
}

/**
 * Download from TikTok
 */
async function downloadFromTikTok(url: string, quality: string) {
  try {
    const videoId = url.split("/").pop()?.split("?")[0] || "";
    return {
      type: "video" as const,
      platform: "tiktok" as const,
      title: `TikTok Video ${videoId}`,
      thumbnail: `https://via.placeholder.com/320x568?text=TikTok+Video`,
      duration: 15,
      quality: quality,
      downloadUrl: `https://example.com/downloads/tiktok/${videoId}.mp4`,
      size: 5242880,
    };
  } catch (error) {
    throw new Error("Failed to download from TikTok");
  }
}

/**
 * Download from Instagram
 */
async function downloadFromInstagram(url: string, quality: string) {
  try {
    const postId = url.split("/").filter((p) => p === "p" || p === "tv" || p === "reel")[1] || "";
    return {
      type: "image" as const,
      platform: "instagram" as const,
      title: `Instagram Post ${postId}`,
      thumbnail: `https://via.placeholder.com/320x320?text=Instagram+Post`,
      quality: quality,
      downloadUrl: `https://example.com/downloads/instagram/${postId}.jpg`,
      size: 2097152,
    };
  } catch (error) {
    throw new Error("Failed to download from Instagram");
  }
}

/**
 * Download from Facebook
 */
async function downloadFromFacebook(url: string, quality: string) {
  try {
    const videoId = url.split("/").pop()?.split("?")[0] || "";
    return {
      type: "video" as const,
      platform: "facebook" as const,
      title: `Facebook Video ${videoId}`,
      thumbnail: `https://via.placeholder.com/320x568?text=Facebook+Video`,
      duration: 30,
      quality: quality,
      downloadUrl: `https://example.com/downloads/facebook/${videoId}.mp4`,
      size: 10485760,
    };
  } catch (error) {
    throw new Error("Failed to download from Facebook");
  }
}

/**
 * Download from YouTube
 */
async function downloadFromYouTube(url: string, quality: string) {
  try {
    const videoId = url.split("v=")[1]?.split("&")[0] || url.split("/").pop() || "";
    return {
      type: "video" as const,
      platform: "youtube" as const,
      title: `YouTube Video ${videoId}`,
      thumbnail: `https://img.youtube.com/vi/${videoId}/0.jpg`,
      duration: 600,
      quality: quality,
      downloadUrl: `https://example.com/downloads/youtube/${videoId}.mp4`,
      size: 52428800,
    };
  } catch (error) {
    throw new Error("Failed to download from YouTube");
  }
}
