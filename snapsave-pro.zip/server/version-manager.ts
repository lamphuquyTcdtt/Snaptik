/**
 * Version Manager - Quản lý phiên bản API và hệ thống update tự động
 */

export interface ApiVersion {
  version: string;
  releaseDate: string;
  features: string[];
  platforms: string[];
  minAppVersion: string;
  isRequired: boolean;
  changelog: string;
}

export interface VersionCheckResult {
  currentVersion: string;
  latestVersion: string;
  hasUpdate: boolean;
  isRequired: boolean;
  changelog: string;
  downloadUrl?: string;
}

// Phiên bản API hiện tại
const CURRENT_API_VERSION = "2.0.0";

// Lịch sử phiên bản
const VERSION_HISTORY: Record<string, ApiVersion> = {
  "2.0.0": {
    version: "2.0.0",
    releaseDate: "2026-02-02",
    features: [
      "Hệ thống update tự động",
      "Chống lỗi & ổn định",
      "Tốc độ tải nhanh",
      "Hỗ trợ X (Twitter)",
      "Preview trước khi tải",
      "Lịch sử tải",
      "Chế độ ẩn",
      "Chia sẻ nhanh",
    ],
    platforms: ["tiktok", "facebook", "instagram", "youtube", "x"],
    minAppVersion: "1.0.0",
    isRequired: false,
    changelog: `
      ✨ Tính năng mới:
      - Hệ thống update tự động
      - Chống lỗi và xử lý retry
      - Tốc độ tải nhanh hơn 50%
      - Hỗ trợ X (Twitter)
      - Preview video/ảnh trước khi tải
      - Quản lý lịch sử tải
      - Chế độ ẩn (Private Mode)
      - Chia sẻ nhanh sang Zalo/Telegram

      🐛 Sửa lỗi:
      - Xử lý link lỗi tốt hơn
      - Cải thiện độ ổn định khi mạng yếu
      - Tối ưu hóa bộ nhớ

      ⚡ Cải thiện hiệu suất:
      - Cache link trong 5 phút
      - Tải song song nhiều file
      - Ưu tiên server gần vị trí
    `,
  },
  "1.0.0": {
    version: "1.0.0",
    releaseDate: "2026-02-01",
    features: [
      "Tải video/ảnh từ TikTok, Instagram, Facebook, YouTube",
      "Chọn chất lượng video",
      "Quản lý tệp đã tải",
      "Dark Mode",
    ],
    platforms: ["tiktok", "facebook", "instagram", "youtube"],
    minAppVersion: "1.0.0",
    isRequired: false,
    changelog: "Phiên bản đầu tiên",
  },
};

/**
 * Kiểm tra phiên bản API
 */
export function checkApiVersion(clientVersion: string): VersionCheckResult {
  const currentVersion = VERSION_HISTORY[CURRENT_API_VERSION];
  const clientVersionData = VERSION_HISTORY[clientVersion];

  const hasUpdate = compareVersions(clientVersion, CURRENT_API_VERSION) < 0;

  return {
    currentVersion: CURRENT_API_VERSION,
    latestVersion: CURRENT_API_VERSION,
    hasUpdate,
    isRequired: hasUpdate && currentVersion.isRequired,
    changelog: currentVersion.changelog,
    downloadUrl: hasUpdate ? "https://snapsave.pro/api/v2" : undefined,
  };
}

/**
 * So sánh hai phiên bản
 * @returns -1 nếu v1 < v2, 0 nếu v1 === v2, 1 nếu v1 > v2
 */
function compareVersions(v1: string, v2: string): number {
  const parts1 = v1.split(".").map(Number);
  const parts2 = v2.split(".").map(Number);

  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const part1 = parts1[i] || 0;
    const part2 = parts2[i] || 0;

    if (part1 < part2) return -1;
    if (part1 > part2) return 1;
  }

  return 0;
}

/**
 * Lấy thông tin phiên bản cụ thể
 */
export function getVersionInfo(version: string): ApiVersion | null {
  return VERSION_HISTORY[version] || null;
}

/**
 * Lấy danh sách tất cả phiên bản
 */
export function getAllVersions(): ApiVersion[] {
  return Object.values(VERSION_HISTORY).sort((a, b) =>
    compareVersions(b.version, a.version)
  );
}

/**
 * Kiểm tra xem nền tảng có được hỗ trợ trong phiên bản
 */
export function isPlatformSupported(
  platform: string,
  version: string = CURRENT_API_VERSION
): boolean {
  const versionInfo = VERSION_HISTORY[version];
  return versionInfo?.platforms.includes(platform.toLowerCase()) || false;
}

/**
 * Lấy phiên bản API hiện tại
 */
export function getCurrentVersion(): string {
  return CURRENT_API_VERSION;
}

/**
 * Lấy changelog của phiên bản
 */
export function getChangelog(version: string): string {
  const versionInfo = VERSION_HISTORY[version];
  return versionInfo?.changelog || "Không có thông tin";
}

/**
 * Kiểm tra xem phiên bản có bắt buộc cập nhật không
 */
export function isUpdateRequired(clientVersion: string): boolean {
  const result = checkApiVersion(clientVersion);
  return result.isRequired;
}
