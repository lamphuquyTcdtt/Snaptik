/** @type {const} */
const themeColors = {
  primary: { light: '#0A7EA4', dark: '#0A9FD9' },
  background: { light: '#FFFFFF', dark: '#0F1419' },
  surface: { light: '#F5F7FA', dark: '#1A1F2E' },
  foreground: { light: '#0F1419', dark: '#F5F7FA' },
  muted: { light: '#6B7280', dark: '#9CA3AF' },
  border: { light: '#E5E7EB', dark: '#2D3748' },
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
