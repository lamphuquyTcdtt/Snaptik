# SnapSave Pro - Thiết Kế Giao Diện Di Động

## Tổng Quan Thiết Kế

**Định Hướng:** Giao diện hiện đại, tối giản, dễ sử dụng với một tay trên thiết bị di động (portrait 9:16). Tuân theo Apple Human Interface Guidelines (HIG) để cảm giác như một ứng dụng iOS chính thức.

**Màu Chủ Đạo:**
- **Màu Chính (Primary):** Xanh dương (#0A7EA4)
- **Màu Nền (Background):** Trắng (#FFFFFF) - Light mode / Đen (#151718) - Dark mode
- **Màu Bề Mặt (Surface):** Xám nhạt (#F5F5F5) - Light mode / Xám đậm (#1E2022) - Dark mode
- **Màu Chữ (Foreground):** Đen (#11181C) - Light mode / Trắng (#ECEDEE) - Dark mode
- **Màu Phụ (Muted):** Xám (#687076) - Light mode / Xám nhạt (#9BA1A6) - Dark mode
- **Màu Lỗi (Error):** Đỏ (#EF4444)
- **Màu Thành Công (Success):** Xanh lá (#22C55E)

**Dark Mode:** Hỗ trợ đầy đủ, tự động chuyển đổi theo cài đặt hệ thống.

---

## Danh Sách Màn Hình

### 1. **Màn Hình Chính (Home Screen)**
Nơi người dùng thực hiện tải video/ảnh.

**Thành Phần Chính:**
- **Header:** Logo SnapSave Pro + Nút Dark Mode Toggle (góc trên phải)
- **Input Link:** Ô nhập URL với placeholder "Dán link TikTok, Instagram, Facebook, YouTube..."
- **Nút Tải Xuống:** Nút chính màu xanh dương, chiều rộng toàn màn hình, kích thước lớn (48px height)
- **Danh Sách Tệp Đã Tải:** ScrollView hiển thị các tệp đã tải (video/ảnh) dưới dạng card nhỏ gọn
- **Thông Báo:** Hiển thị trạng thái (đang tải, thành công, lỗi)

**Chức Năng:**
- Tự động nhận link từ clipboard khi mở ứng dụng
- Hiển thị thông báo cảnh báo: "Chỉ tải nội dung bạn có quyền sử dụng"
- Nút tải có loading state (spinner)

---

### 2. **Màn Hình Chi Tiết Tệp (File Detail Screen)**
Hiển thị chi tiết video/ảnh đã tải và các tùy chọn.

**Thành Phần Chính:**
- **Hình Ảnh Xem Trước:** Thumbnail video hoặc ảnh gốc
- **Thông Tin Tệp:** Tên, kích thước, định dạng, thời lượng (nếu là video)
- **Chọn Chất Lượng (Video):** Radio buttons - SD / HD / Full HD
- **Nút Hành Động:**
  - Tải Xuống (Download)
  - Chia Sẻ (Share)
  - Xóa (Delete)
- **Lịch Sử:** Hiển thị ngày/giờ tải

---

### 3. **Màn Hình Danh Sách Tệp (Downloads List)**
Xem tất cả tệp đã tải.

**Thành Phần Chính:**
- **Header:** "Tệp Đã Tải" + Nút Xóa Tất Cả
- **Danh Sách:** FlatList hiển thị các tệp dạng card (thumbnail + tên + ngày tải)
- **Sắp Xếp:** Mới nhất trước
- **Xóa Từng Tệp:** Swipe left hoặc nút delete trên card

---

### 4. **Màn Hình Cài Đặt (Settings)**
Tùy chọn ứng dụng.

**Thành Phần Chính:**
- **Dark Mode Toggle:** Bật/Tắt Dark Mode
- **Thông Báo:** Bật/Tắt thông báo
- **Xóa Dữ Liệu:** Xóa tất cả tệp đã tải
- **Thông Tin Ứng Dụng:** Phiên bản, tác giả
- **Điều Khoản Sử Dụng:** Link đến điều khoản

---

## Luồng Người Dùng Chính

### **Luồng 1: Tải Video/Ảnh**
1. Người dùng mở ứng dụng → Màn hình chính
2. Dán link từ clipboard (tự động) hoặc nhập thủ công
3. Nhấn nút "Tải Xuống"
4. Ứng dụng hiển thị loading spinner
5. Chọn chất lượng (nếu video)
6. Tệp tải thành công → Hiển thị thông báo "Tải thành công"
7. Tệp xuất hiện trong danh sách "Tệp Đã Tải"

### **Luồng 2: Xem Chi Tiết Tệp**
1. Người dùng nhấn vào tệp trong danh sách
2. Chuyển đến màn hình chi tiết
3. Xem thông tin, chọn chất lượng, tải xuống hoặc chia sẻ

### **Luồng 3: Chia Sẻ Tệp**
1. Người dùng nhấn nút "Chia Sẻ"
2. Bộ chia sẻ hệ thống mở
3. Chọn ứng dụng để chia sẻ

---

## Quy Tắc Thiết Kế

### **Khoảng Cách & Padding**
- Padding ngoài (Screen): 16px
- Khoảng cách giữa các phần tử: 12-16px
- Card padding: 12px
- Border radius: 12px (card), 24px (button)

### **Typography**
- **Tiêu Đề Lớn:** 28px, Bold
- **Tiêu Đề Phụ:** 18px, Semibold
- **Body:** 16px, Regular
- **Caption:** 12px, Regular (muted color)

### **Interaction**
- **Button Press:** Scale 0.97 + Haptic feedback (Light)
- **Card Press:** Opacity 0.7
- **Loading:** Spinner animation
- **Success:** Notification + Haptic (Success)
- **Error:** Notification + Haptic (Error)

### **Responsive Design**
- Màn hình nhỏ (< 375px): Giảm padding, font size nhỏ hơn
- Màn hình lớn (> 430px): Tăng padding, font size lớn hơn
- Tab bar: Luôn ở dưới, không bị ẩn

---

## Tính Năng Bổ Sung

1. **Tự Động Nhận Link:** Kiểm tra clipboard khi mở ứng dụng
2. **Dark Mode:** Hỗ trợ đầy đủ, lưu tùy chọn
3. **Lưu Tệp:** Lưu vào thư viện máy (MediaLibrary)
4. **Chia Sẻ:** Chia sẻ qua các ứng dụng khác
5. **Thông Báo:** Thông báo khi tải xong
6. **Không Đăng Nhập:** Ứng dụng hoạt động mà không cần tài khoản

---

## Cảnh Báo & Tuân Thủ

- **Cảnh Báo Bản Quyền:** Hiển thị rõ ràng "Chỉ tải nội dung bạn có quyền sử dụng"
- **Không Lưu Dữ Liệu:** Không lưu thông tin người dùng, chỉ lưu danh sách tệp cục bộ
- **Không Watermark:** Tệp tải không chứa watermark hoặc logo
