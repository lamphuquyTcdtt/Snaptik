# SnapSave Pro - TODO List

## Giai Đoạn 1: Thiết Kế & Kiến Trúc
- [x] Thiết kế giao diện (design.md)
- [x] Xác định kiến trúc backend API
- [x] Lên kế hoạch tích hợp các nền tảng (TikTok, Instagram, Facebook, YouTube)

## Giai Đoạn 2: Backend API
- [x] Thiết lập server Express.js
- [x] Tạo endpoint `/api/download` xử lý link
- [x] Tích hợp TikTok downloader (mock)
- [x] Tích hợp Instagram downloader (mock)
- [x] Tích hợp Facebook downloader (mock)
- [x] Tích hợp YouTube downloader (mock)
- [x] Xử lý chất lượng video (SD/HD/Full HD)
- [x] Xử lý lỗi và validation

## Giai Đoạn 3: Giao Diện Người Dùng
- [x] Cấu hình màu sắc (theme.config.js)
- [x] Thiết kế màn hình chính (Home)
- [x] Tạo component Input Link
- [x] Tạo component Nút Tải Xuống
- [x] Tạo component Danh Sách Tệp
- [ ] Tạo màn hình Chi Tiết Tệp
- [ ] Tạo màn hình Danh Sách Tệp Đã Tải
- [x] Tạo màn hình Cài Đặt
- [x] Tạo Tab Navigation

## Giai Đoạn 4: Tính Năng Clipboard
- [x] Tự động nhận link từ clipboard
- [x] Hiển thị thông báo khi phát hiện link
- [x] Xử lý link không hợp lệ

## Giai Đoạn 5: Tính Năng Lưu & Chia Sẻ
- [x] Lưu tệp vào thư viện máy (MediaLibrary)
- [x] Tích hợp chia sẻ (Share API)
- [x] Xử lý quyền truy cập file
- [x] Lưu danh sách tệp vào AsyncStorage

## Giai Đoạn 6: Dark Mode & Cài Đặt
- [x] Thiết lập Dark Mode toggle
- [x] Lưu tùy chọn Dark Mode
- [x] Tạo màn hình Cài Đặt
- [x] Tùy chọn Xóa Dữ Liệu
- [x] Tùy chọn Thông Báo

## Giai Đoạn 7: Tối Ưu & Kiểm Tra
- [x] Kiểm tra hiệu suất
- [ ] Kiểm tra trên iOS
- [ ] Kiểm tra trên Android
- [ ] Kiểm tra trên Web
- [ ] Xử lý lỗi edge cases
- [ ] Tối ưu hóa UI/UX

## Giai Đoạn 8: Logo & Branding
- [x] Tạo logo ứng dụng
- [x] Cập nhật app.config.ts
- [x] Tạo splash screen
- [x] Tạo favicon

## Giai Đoạn 9: Build & Deployment
- [ ] Build APK cho Android
- [ ] Build IPA cho iOS
- [ ] Kiểm tra build
- [ ] Chuẩn bị hướng dẫn sử dụng


## NÂNG CẤP PRO - PHIÊN BẢN MỚI

### Giai Đoạn 1: Hệ Thống Update Tự Động
- [x] Tạo API endpoint kiểm tra phiên bản
- [x] Xây dựng hệ thống quản lý phiên bản backend
- [x] Thông báo cập nhật trong app
- [x] Tự động tải API mới mà không cần cập nhật app

### Giai Đoạn 2: Chống Lỗi & Ổn Định
- [x] Phát hiện link lỗi (link riêng tư, link chết)
- [x] Hiển thị lý do lỗi rõ ràng
- [x] Tính năng Retry tự động khi mạng yếu
- [x] Xử lý timeout và connection errors

### Giai Đoạn 3: Nâng Cấp Tốc Độ
- [x] Tải song song nhiều file
- [x] Ưu tiên server gần vị trí người dùng
- [x] Cache link trong 5 phút
- [x] Tối ưu hóa request/response

### Giai Đoạn 4: Nền Tảng Mới
- [x] Thêm hỗ trợ X (Twitter)
- [x] Hỗ trợ video nhiều phần
- [x] Hỗ trợ album ảnh
- [x] Chất lượng 4K (nếu có)

### Giai Đoạn 5: Tính Năng Preview
- [x] Preview video/ảnh trước khi tải
- [x] Hiển thị thông tin metadata
- [x] Chọn file cụ thể từ album

### Giai Đoạn 6: Lịch Sử & Chế Độ Ẩn
- [x] Quản lý lịch sử tải
- [x] Chế độ ẩn (Private Mode)
- [x] Xóa lịch sử tự động
- [x] Đổi tên file trước khi lưu

### Giai Đoạn 7: Chia Sẻ Nhanh
- [x] Chia sẻ sang Zalo
- [x] Chia sẻ sang Telegram
- [x] Chia sẻ sang các ứng dụng khác
- [x] Copy link tải nhanh

### Giai Đoạn 8: Bảo Mật & Pháp Lý
- [ ] Không lưu link người dùng
- [ ] Không thu thập dữ liệu cá nhân
- [ ] Cảnh báo bản quyền rõ ràng
- [ ] Chính sách bảo mật cập nhật

### Giai Đoạn 9: Tính Năng PRO (Tùy Chọn)
- [ ] Hệ thống subscription
- [ ] Không quảng cáo
- [ ] Tốc độ tải ưu tiên
- [ ] Tải hàng loạt không giới hạn
