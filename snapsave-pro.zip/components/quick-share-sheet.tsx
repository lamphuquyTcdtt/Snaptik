import { Modal, View, Text, Pressable, ScrollView, Alert } from "react-native";
import { useState, useEffect } from "react";
import { useColors } from "@/hooks/use-colors";
import { useQuickShare, ShareTarget } from "@/hooks/use-quick-share";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

export interface QuickShareSheetProps {
  visible: boolean;
  title: string;
  message: string;
  fileUri?: string;
  onClose: () => void;
}

interface ShareOption {
  target: ShareTarget;
  label: string;
  icon: string;
  color: string;
}

export function QuickShareSheet({
  visible,
  title,
  message,
  fileUri,
  onClose,
}: QuickShareSheetProps) {
  const colors = useColors();
  const {
    shareToZalo,
    shareToTelegram,
    shareToWhatsApp,
    shareToFacebook,
    shareToTwitter,
    shareGeneric,
    copyToClipboard,
    getAvailableTargets,
  } = useQuickShare();

  const [availableTargets, setAvailableTargets] = useState<ShareTarget[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (visible) {
      loadAvailableTargets();
    }
  }, [visible]);

  const loadAvailableTargets = async () => {
    try {
      const targets = await getAvailableTargets();
      setAvailableTargets(targets);
    } catch (error) {
      console.error("Failed to load available targets:", error);
    }
  };

  const shareOptions: ShareOption[] = [
    {
      target: ShareTarget.ZALO,
      label: "Zalo",
      icon: "share",
      color: "#0084FF",
    },
    {
      target: ShareTarget.TELEGRAM,
      label: "Telegram",
      icon: "send",
      color: "#0088cc",
    },
    {
      target: ShareTarget.WHATSAPP,
      label: "WhatsApp",
      icon: "chat",
      color: "#25D366",
    },
    {
      target: ShareTarget.FACEBOOK,
      label: "Facebook",
      icon: "share",
      color: "#1877F2",
    },
    {
      target: ShareTarget.TWITTER,
      label: "Twitter",
      icon: "share",
      color: "#1DA1F2",
    },
  ];

  const handleShare = async (target: ShareTarget) => {
    try {
      setIsLoading(true);
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      let success = false;

      switch (target) {
        case ShareTarget.ZALO:
          success = await shareToZalo({ title, message, fileUri });
          break;
        case ShareTarget.TELEGRAM:
          success = await shareToTelegram({ title, message, fileUri });
          break;
        case ShareTarget.WHATSAPP:
          success = await shareToWhatsApp({ title, message, fileUri });
          break;
        case ShareTarget.FACEBOOK:
          success = await shareToFacebook({ title, message, fileUri });
          break;
        case ShareTarget.TWITTER:
          success = await shareToTwitter({ title, message, fileUri });
          break;
        default:
          success = await shareGeneric({ title, message, fileUri });
      }

      if (success) {
        onClose();
      }
    } catch (error) {
      console.error("Failed to share:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyLink = async () => {
    try {
      await copyToClipboard(message, "Đã sao chép vào clipboard");
      onClose();
    } catch (error) {
      console.error("Failed to copy:", error);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View
        className="flex-1"
        style={{
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
      >
        {/* Overlay */}
        <Pressable
          className="flex-1"
          onPress={onClose}
        />

        {/* Bottom Sheet */}
        <View
          className="rounded-t-3xl p-6"
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
          }}
        >
          {/* Handle */}
          <View className="items-center mb-4">
            <View
              className="w-10 h-1 rounded-full"
              style={{ backgroundColor: colors.border }}
            />
          </View>

          {/* Header */}
          <View className="gap-2 mb-6">
            <Text
              className="text-2xl font-bold"
              style={{ color: colors.foreground }}
            >
              Chia Sẻ
            </Text>
            <Text
              className="text-sm"
              style={{ color: colors.muted }}
            >
              Chọn cách chia sẻ nội dung
            </Text>
          </View>

          {/* Share Options */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="mb-6"
          >
            <View className="flex-row gap-4">
              {shareOptions.map((option) => {
                const isAvailable = availableTargets.includes(option.target);

                return (
                  <Pressable
                    key={option.target}
                    onPress={() => handleShare(option.target)}
                    disabled={!isAvailable || isLoading}
                    style={({ pressed }) => [
                      {
                        opacity: !isAvailable ? 0.5 : pressed ? 0.7 : 1,
                      },
                    ]}
                  >
                    <View className="items-center gap-2">
                      <View
                        className="w-16 h-16 rounded-full items-center justify-center"
                        style={{
                          backgroundColor: isAvailable ? option.color + "20" : colors.surface,
                        }}
                      >
                        <MaterialIcons
                          name={option.icon as any}
                          size={28}
                          color={isAvailable ? option.color : colors.muted}
                        />
                      </View>
                      <Text
                        className="text-xs font-semibold"
                        style={{
                          color: isAvailable ? colors.foreground : colors.muted,
                        }}
                      >
                        {option.label}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>

          {/* Copy & Generic Share */}
          <View className="gap-3">
            {/* Copy Link */}
            <Pressable
              onPress={handleCopyLink}
              disabled={isLoading}
              style={({ pressed }) => [
                {
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  borderRadius: 12,
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 1,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <View className="flex-row items-center justify-center gap-3">
                <MaterialIcons name="content-copy" size={20} color={colors.primary} />
                <Text
                  className="font-semibold"
                  style={{ color: colors.foreground }}
                >
                  Sao Chép Link
                </Text>
              </View>
            </Pressable>

            {/* Generic Share */}
            <Pressable
              onPress={() => handleShare(ShareTarget.GENERIC)}
              disabled={isLoading}
              style={({ pressed }) => [
                {
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  borderRadius: 12,
                  backgroundColor: colors.primary,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <View className="flex-row items-center justify-center gap-3">
                <MaterialIcons name="share" size={20} color={colors.background} />
                <Text
                  className="font-semibold"
                  style={{ color: colors.background }}
                >
                  Chia Sẻ Khác
                </Text>
              </View>
            </Pressable>

            {/* Close */}
            <Pressable
              onPress={onClose}
              style={({ pressed }) => [
                {
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  borderRadius: 12,
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderWidth: 1,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <Text
                className="text-center font-semibold"
                style={{ color: colors.foreground }}
              >
                Đóng
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}
