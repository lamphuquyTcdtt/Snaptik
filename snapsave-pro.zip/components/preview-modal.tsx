import { Modal, View, Text, Pressable, ScrollView, Image, FlatList } from "react-native";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

export interface PreviewModalProps {
  visible: boolean;
  preview: any | null;
  onClose: () => void;
  onDownload: (selectedItems?: string[]) => void;
  isLoading?: boolean;
}

export function PreviewModal({
  visible,
  preview,
  onClose,
  onDownload,
  isLoading = false,
}: PreviewModalProps) {
  const colors = useColors();

  if (!preview) return null;

  const handleDownload = () => {
    onDownload();
    onClose();
  };

  const formatDuration = (seconds?: number): string => {
    if (!seconds) return "Unknown";
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    }
    return `${minutes}:${secs.toString().padStart(2, "0")}`;
  };

  const formatSize = (bytes?: number): string => {
    if (!bytes) return "Unknown";
    const units = ["B", "KB", "MB", "GB"];
    let size = bytes;
    let unitIndex = 0;

    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }

    return `${size.toFixed(2)} ${units[unitIndex]}`;
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
      onRequestClose={onClose}
    >
      <View style={{ backgroundColor: colors.background, flex: 1 }}>
        {/* Header */}
        <View
          className="flex-row items-center justify-between p-4"
          style={{
            backgroundColor: colors.surface,
            borderBottomColor: colors.border,
            borderBottomWidth: 1,
          }}
        >
          <Text
            className="text-lg font-bold"
            style={{ color: colors.foreground }}
          >
            Preview
          </Text>
          <Pressable
            onPress={onClose}
            style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
          >
            <MaterialIcons name="close" size={24} color={colors.foreground} />
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        >
          <View className="p-4 gap-4">
            {/* Thumbnail */}
            {preview.thumbnail && (
              <Image
                source={{ uri: preview.thumbnail }}
                className="w-full h-48 rounded-lg"
                style={{ backgroundColor: colors.surface }}
              />
            )}

            {/* Title & Description */}
            <View className="gap-2">
              <Text
                className="text-xl font-bold"
                style={{ color: colors.foreground }}
              >
                {preview.title}
              </Text>
              {preview.description && (
                <Text
                  className="text-sm"
                  style={{ color: colors.muted }}
                >
                  {preview.description}
                </Text>
              )}
            </View>

            {/* Metadata */}
            <View
              className="rounded-lg p-4 gap-3"
              style={{
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
              }}
            >
              {/* Platform */}
              <View className="flex-row items-center justify-between">
                <Text style={{ color: colors.muted }}>Nền tảng</Text>
                <View
                  className="px-3 py-1 rounded-full"
                  style={{ backgroundColor: colors.primary + "20" }}
                >
                  <Text
                    className="text-sm font-semibold capitalize"
                    style={{ color: colors.primary }}
                  >
                    {preview.platform}
                  </Text>
                </View>
              </View>

              {/* Duration */}
              {preview.duration && (
                <View className="flex-row items-center justify-between">
                  <Text style={{ color: colors.muted }}>Thời lượng</Text>
                  <Text
                    className="font-semibold"
                    style={{ color: colors.foreground }}
                  >
                    {formatDuration(preview.duration)}
                  </Text>
                </View>
              )}

              {/* Size */}
              {preview.size && (
                <View className="flex-row items-center justify-between">
                  <Text style={{ color: colors.muted }}>Kích thước</Text>
                  <Text
                    className="font-semibold"
                    style={{ color: colors.foreground }}
                  >
                    {formatSize(preview.size)}
                  </Text>
                </View>
              )}

              {/* Author */}
              {preview.author && (
                <View className="flex-row items-center justify-between">
                  <Text style={{ color: colors.muted }}>Tác giả</Text>
                  <Text
                    className="font-semibold"
                    style={{ color: colors.foreground }}
                  >
                    {preview.author}
                  </Text>
                </View>
              )}

              {/* Quality */}
              {preview.quality && preview.quality.length > 0 && (
                <View>
                  <Text style={{ color: colors.muted, marginBottom: 8 }}>
                    Chất lượng có sẵn
                  </Text>
                  <View className="flex-row flex-wrap gap-2">
                    {preview.quality.map((q: string) => (
                      <View
                        key={q}
                        className="px-3 py-1 rounded-full"
                        style={{
                          backgroundColor: colors.primary + "20",
                        }}
                      >
                        <Text
                          className="text-xs font-semibold uppercase"
                          style={{ color: colors.primary }}
                        >
                          {q}
                        </Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </View>

            {/* Items (for albums) */}
            {preview.items && preview.items.length > 0 && (
              <View className="gap-3">
                <Text
                  className="text-lg font-bold"
                  style={{ color: colors.foreground }}
                >
                  Album ({preview.items.length} tệp)
                </Text>

                <FlatList
                  data={preview.items}
                  renderItem={({ item }) => (
                    <View
                      className="w-20 h-20 rounded-lg mr-2 mb-2 items-center justify-center"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: item.selected ? colors.primary : colors.border,
                        borderWidth: 2,
                      }}
                    >
                      <Image
                        source={{ uri: item.thumbnail }}
                        className="w-full h-full rounded-lg"
                      />
                      {item.selected && (
                        <View
                          className="absolute top-1 right-1 w-5 h-5 rounded-full items-center justify-center"
                          style={{ backgroundColor: colors.primary }}
                        >
                          <MaterialIcons
                            name="check"
                            size={14}
                            color={colors.background}
                          />
                        </View>
                      )}
                    </View>
                  )}
                  keyExtractor={(item) => item.id}
                  numColumns={4}
                  scrollEnabled={false}
                />
              </View>
            )}

            {/* Copyright Warning */}
            <View
              className="rounded-lg p-4"
              style={{ backgroundColor: colors.warning + "20" }}
            >
              <View className="flex-row items-flex-start gap-3">
                <MaterialIcons
                  name="warning"
                  size={20}
                  color={colors.warning}
                  style={{ marginTop: 2 }}
                />
                <Text
                  className="text-xs leading-relaxed flex-1"
                  style={{ color: colors.warning }}
                >
                  Chỉ tải nội dung mà bạn có quyền sử dụng. SnapSave Pro không chịu trách
                  nhiệm về bất kỳ vi phạm bản quyền nào.
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>

        {/* Footer Actions */}
        <View
          className="flex-row gap-3 p-4"
          style={{
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            borderTopWidth: 1,
          }}
        >
          <Pressable
            onPress={onClose}
            style={({ pressed }) => [
              {
                flex: 1,
                paddingVertical: 12,
                borderRadius: 8,
                backgroundColor: colors.border,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <Text
              className="text-center font-semibold"
              style={{ color: colors.foreground }}
            >
              Hủy
            </Text>
          </Pressable>

          <Pressable
            onPress={handleDownload}
            disabled={isLoading}
            style={({ pressed }) => [
              {
                flex: 1,
                paddingVertical: 12,
                borderRadius: 8,
                backgroundColor: colors.primary,
                opacity: pressed || isLoading ? 0.7 : 1,
              },
            ]}
          >
            <View className="flex-row items-center justify-center gap-2">
              {isLoading && (
                <MaterialIcons name="hourglass-empty" size={18} color={colors.background} />
              )}
              <Text
                className="text-center font-semibold"
                style={{ color: colors.background }}
              >
                {isLoading ? "Đang tải..." : "Tải Xuống"}
              </Text>
            </View>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
