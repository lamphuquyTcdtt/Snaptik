import { Pressable, Text, View, ActivityIndicator } from "react-native";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

interface DownloadButtonProps {
  onPress: () => void;
  isLoading?: boolean;
  disabled?: boolean;
  title?: string;
}

export function DownloadButton({
  onPress,
  isLoading = false,
  disabled = false,
  title = "Tải Xuống",
}: DownloadButtonProps) {
  const colors = useColors();

  const handlePress = async () => {
    if (!isLoading && !disabled) {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onPress();
    }
  };

  return (
    <Pressable
      onPress={handlePress}
      disabled={disabled || isLoading}
      style={({ pressed }) => [
        {
          opacity: disabled || isLoading ? 0.5 : pressed ? 0.9 : 1,
          transform: [{ scale: pressed && !disabled && !isLoading ? 0.97 : 1 }],
        },
      ]}
    >
      <View
        className="flex-row items-center justify-center gap-2 rounded-2xl py-4 px-6"
        style={{
          backgroundColor: disabled || isLoading ? colors.muted : colors.primary,
        }}
      >
        {isLoading ? (
          <ActivityIndicator color={colors.background} size="small" />
        ) : (
          <MaterialIcons name="download" size={20} color={colors.background} />
        )}
        <Text
          className="text-center font-semibold text-base"
          style={{
            color: colors.background,
          }}
        >
          {title}
        </Text>
      </View>
    </Pressable>
  );
}
