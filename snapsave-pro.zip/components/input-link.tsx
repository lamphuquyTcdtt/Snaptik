import { View, TextInput, Pressable, Text, ActivityIndicator } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { cn } from "@/lib/utils";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

interface InputLinkProps {
  value: string;
  onChangeText: (text: string) => void;
  onPaste?: () => void;
  isLoading?: boolean;
  placeholder?: string;
}

export function InputLink({
  value,
  onChangeText,
  onPaste,
  isLoading = false,
  placeholder = "Dán link TikTok, Instagram, Facebook, YouTube...",
}: InputLinkProps) {
  const colors = useColors();

  return (
    <View className="gap-3">
      <View
        className="flex-row items-center rounded-2xl border px-4 py-3 gap-2"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
        }}
      >
        <MaterialIcons name="link" size={20} color={colors.primary} />
        <TextInput
          className="flex-1 text-base text-foreground"
          placeholder={placeholder}
          placeholderTextColor={colors.muted}
          value={value}
          onChangeText={onChangeText}
          editable={!isLoading}
          style={{
            color: colors.foreground,
          }}
        />
        {isLoading && <ActivityIndicator color={colors.primary} />}
        {!isLoading && onPaste && (
          <Pressable
            onPress={onPaste}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <MaterialIcons name="content-paste" size={20} color={colors.primary} />
          </Pressable>
        )}
      </View>
    </View>
  );
}
