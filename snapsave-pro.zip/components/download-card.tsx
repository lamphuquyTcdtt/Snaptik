import { View, Text, Pressable, Image } from "react-native";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

interface DownloadCardProps {
  title: string;
  platform: "tiktok" | "instagram" | "facebook" | "youtube";
  thumbnail?: string;
  type: "video" | "image";
  duration?: number;
  size?: number;
  onPress?: () => void;
  onDelete?: () => void;
  onShare?: () => void;
}

export function DownloadCard({
  title,
  platform,
  thumbnail,
  type,
  duration,
  size,
  onPress,
  onDelete,
  onShare,
}: DownloadCardProps) {
  const colors = useColors();

  const formatSize = (bytes?: number) => {
    if (!bytes) return "Unknown";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return "";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getPlatformColor = () => {
    switch (platform) {
      case "tiktok":
        return "#000000";
      case "instagram":
        return "#E1306C";
      case "facebook":
        return "#1877F2";
      case "youtube":
        return "#FF0000";
      default:
        return colors.primary;
    }
  };

  const handlePress = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress?.();
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        {
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <View
        className="flex-row gap-3 rounded-xl p-3 overflow-hidden"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderWidth: 1,
        }}
      >
        {/* Thumbnail */}
        <View className="relative w-16 h-16 rounded-lg overflow-hidden bg-muted">
          {thumbnail ? (
            <Image source={{ uri: thumbnail }} className="w-full h-full" />
          ) : (
            <View className="flex-1 items-center justify-center">
              <MaterialIcons
                name={type === "video" ? "video-library" : "image"}
                size={24}
                color={colors.muted}
              />
            </View>
          )}

          {/* Platform Badge */}
          <View
            className="absolute top-1 right-1 rounded-full px-2 py-1"
            style={{ backgroundColor: getPlatformColor() }}
          >
            <Text className="text-white text-xs font-semibold uppercase">{platform[0]}</Text>
          </View>

          {/* Duration Badge (for videos) */}
          {type === "video" && duration && (
            <View className="absolute bottom-1 right-1 bg-black/70 rounded px-1.5 py-0.5">
              <Text className="text-white text-xs font-semibold">{formatDuration(duration)}</Text>
            </View>
          )}
        </View>

        {/* Content */}
        <View className="flex-1 justify-between">
          <View>
            <Text
              className="text-sm font-semibold text-foreground"
              numberOfLines={2}
              style={{ color: colors.foreground }}
            >
              {title}
            </Text>
            <Text className="text-xs text-muted mt-1" style={{ color: colors.muted }}>
              {type === "video" ? "Video" : "Image"} • {formatSize(size)}
            </Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View className="justify-center gap-2">
          {onShare && (
            <Pressable
              onPress={onShare}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <MaterialIcons name="share" size={18} color={colors.primary} />
            </Pressable>
          )}
          {onDelete && (
            <Pressable
              onPress={onDelete}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
            >
              <MaterialIcons name="delete" size={18} color={colors.error} />
            </Pressable>
          )}
        </View>
      </View>
    </Pressable>
  );
}
