import { ScrollView, View, Text, Pressable, FlatList, Alert } from "react-native";
import { useState, useEffect } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useDownloadHistory } from "@/hooks/use-download-history";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

export default function HistoryScreen() {
  const colors = useColors();
  const {
    history,
    privateMode,
    autoDeleteHistory,
    isLoading,
    deleteEntry,
    clearHistory,
    togglePrivateMode,
    toggleAutoDeleteHistory,
    searchHistory,
    getStatistics,
  } = useDownloadHistory();

  const [searchQuery, setSearchQuery] = useState("");
  const [filteredHistory, setFilteredHistory] = useState(history);
  const [stats, setStats] = useState(getStatistics());

  useEffect(() => {
    if (searchQuery) {
      setFilteredHistory(searchHistory(searchQuery));
    } else {
      setFilteredHistory(history);
    }
    setStats(getStatistics());
  }, [history, searchQuery]);

  const handleDeleteEntry = (id: string, title: string) => {
    Alert.alert("Xóa", `Xóa "${title}" khỏi lịch sử?`, [
      { text: "Hủy", style: "cancel" },
      {
        text: "Xóa",
        style: "destructive",
        onPress: async () => {
          await deleteEntry(id);
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
      },
    ]);
  };

  const handleClearAll = () => {
    Alert.alert("Xóa Tất Cả", "Bạn có chắc muốn xóa tất cả lịch sử?", [
      { text: "Hủy", style: "cancel" },
      {
        text: "Xóa",
        style: "destructive",
        onPress: async () => {
          await clearHistory();
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
      },
    ]);
  };

  const HistoryItem = ({ item }: { item: any }) => (
    <Pressable
      onPress={() => {}}
      style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
    >
      <View
        className="flex-row items-center justify-between p-3 rounded-lg mb-2"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderWidth: 1,
        }}
      >
        <View className="flex-row items-center gap-3 flex-1">
          <View
            className="w-10 h-10 rounded-lg items-center justify-center"
            style={{
              backgroundColor:
                item.status === "success" ? colors.success + "20" : colors.error + "20",
            }}
          >
            <MaterialIcons
              name={item.status === "success" ? "check-circle" : "error"}
              size={20}
              color={item.status === "success" ? colors.success : colors.error}
            />
          </View>

          <View className="flex-1">
            <Text
              className="text-sm font-semibold"
              style={{ color: colors.foreground }}
              numberOfLines={1}
            >
              {item.title}
            </Text>
            <View className="flex-row items-center gap-2 mt-1">
              <Text
                className="text-xs px-2 py-1 rounded"
                style={{
                  backgroundColor: colors.primary + "20",
                  color: colors.primary,
                }}
              >
                {item.platform}
              </Text>
              <Text className="text-xs" style={{ color: colors.muted }}>
                {new Date(item.timestamp).toLocaleDateString("vi-VN")}
              </Text>
            </View>
          </View>
        </View>

        <Pressable
          onPress={() => handleDeleteEntry(item.id, item.title)}
          style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
        >
          <MaterialIcons name="delete-outline" size={20} color={colors.error} />
        </Pressable>
      </View>
    </Pressable>
  );

  if (isLoading) {
    return (
      <ScreenContainer className="p-4 items-center justify-center">
        <MaterialIcons name="history" size={48} color={colors.muted} />
        <Text className="mt-4" style={{ color: colors.muted }}>
          Đang tải lịch sử...
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4 pb-6">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-3xl font-bold"
              style={{ color: colors.foreground }}
            >
              Lịch Sử Tải
            </Text>
            <Text
              className="text-sm"
              style={{ color: colors.muted }}
            >
              Quản lý các tệp đã tải
            </Text>
          </View>

          {/* Statistics */}
          <View className="grid grid-cols-3 gap-3">
            <View
              className="rounded-lg p-3 items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <Text
                className="text-2xl font-bold"
                style={{ color: colors.primary }}
              >
                {stats.total}
              </Text>
              <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                Tổng cộng
              </Text>
            </View>

            <View
              className="rounded-lg p-3 items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <Text
                className="text-2xl font-bold"
                style={{ color: colors.success }}
              >
                {stats.successful}
              </Text>
              <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                Thành công
              </Text>
            </View>

            <View
              className="rounded-lg p-3 items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <Text
                className="text-2xl font-bold"
                style={{ color: colors.error }}
              >
                {stats.failed}
              </Text>
              <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                Thất bại
              </Text>
            </View>
          </View>

          {/* Private Mode */}
          <View
            className="rounded-lg p-4"
            style={{
              backgroundColor: privateMode ? colors.primary + "20" : colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
            }}
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center gap-3 flex-1">
                <MaterialIcons
                  name={privateMode ? "lock" : "lock-open"}
                  size={20}
                  color={privateMode ? colors.primary : colors.muted}
                />
                <View>
                  <Text
                    className="text-sm font-semibold"
                    style={{ color: colors.foreground }}
                  >
                    Chế Độ Ẩn
                  </Text>
                  <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                    {privateMode ? "Bật - Lịch sử sẽ không được lưu" : "Tắt"}
                  </Text>
                </View>
              </View>

              <Pressable
                onPress={() => togglePrivateMode(!privateMode)}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className="w-12 h-6 rounded-full items-center justify-center"
                  style={{
                    backgroundColor: privateMode ? colors.primary : colors.border,
                  }}
                >
                  <View
                    className="w-5 h-5 rounded-full"
                    style={{
                      backgroundColor: colors.background,
                      marginLeft: privateMode ? 3 : -3,
                    }}
                  />
                </View>
              </Pressable>
            </View>
          </View>

          {/* Auto Delete History */}
          <View
            className="rounded-lg p-4"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
            }}
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center gap-3 flex-1">
                <MaterialIcons name="delete-sweep" size={20} color={colors.warning} />
                <View>
                  <Text
                    className="text-sm font-semibold"
                    style={{ color: colors.foreground }}
                  >
                    Xóa Lịch Sử Cũ
                  </Text>
                  <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                    {autoDeleteHistory ? "Tự động xóa sau 30 ngày" : "Giữ lịch sử"}
                  </Text>
                </View>
              </View>

              <Pressable
                onPress={() => toggleAutoDeleteHistory(!autoDeleteHistory)}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View
                  className="w-12 h-6 rounded-full items-center justify-center"
                  style={{
                    backgroundColor: autoDeleteHistory ? colors.primary : colors.border,
                  }}
                >
                  <View
                    className="w-5 h-5 rounded-full"
                    style={{
                      backgroundColor: colors.background,
                      marginLeft: autoDeleteHistory ? 3 : -3,
                    }}
                  />
                </View>
              </Pressable>
            </View>
          </View>

          {/* History List */}
          {filteredHistory.length > 0 ? (
            <View className="gap-2">
              <View className="flex-row items-center justify-between">
                <Text
                  className="text-lg font-semibold"
                  style={{ color: colors.foreground }}
                >
                  Lịch Sử ({filteredHistory.length})
                </Text>
                {filteredHistory.length > 0 && (
                  <Pressable
                    onPress={handleClearAll}
                    style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
                  >
                    <Text
                      className="text-sm font-semibold"
                      style={{ color: colors.error }}
                    >
                      Xóa Tất Cả
                    </Text>
                  </Pressable>
                )}
              </View>

              <FlatList
                data={filteredHistory}
                renderItem={({ item }) => <HistoryItem item={item} />}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
              />
            </View>
          ) : (
            <View className="items-center justify-center py-12">
              <MaterialIcons name="history" size={48} color={colors.muted} />
              <Text
                className="text-sm mt-4"
                style={{ color: colors.muted }}
              >
                {privateMode ? "Chế độ ẩn - Lịch sử không được lưu" : "Chưa có lịch sử"}
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
