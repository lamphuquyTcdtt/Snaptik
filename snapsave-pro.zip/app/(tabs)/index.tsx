import { ScrollView, View, Text, FlatList, Alert } from "react-native";
import { useState, useEffect } from "react";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { InputLink } from "@/components/input-link";
import { DownloadButton } from "@/components/download-button";
import { DownloadCard } from "@/components/download-card";
import { useDownloads, type Download } from "@/hooks/use-downloads";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export default function HomeScreen() {
  const colors = useColors();
  const { downloads, addDownload, removeDownload } = useDownloads();
  const [url, setUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [quality, setQuality] = useState<"sd" | "hd" | "full_hd">("hd");

  // Validate URL on the backend
  const validateUrlMutation = trpc.download.validateUrl.useQuery(
    { url },
    { enabled: url.length > 0 }
  );

  // Download mutation
  const downloadMutation = trpc.download.fetch.useMutation({
    onSuccess: async (result) => {
      if (result.success && result.data) {
        try {
          const download = await addDownload({
            url,
            platform: result.data.platform as Download["platform"],
            title: result.data.title || "Untitled",
            thumbnail: result.data.thumbnail,
            type: result.data.type as "video" | "image",
            duration: result.data.type === "video" ? result.data.duration : undefined,
            size: result.data.size,
            quality,
            downloadUrl: result.data.downloadUrl,
          });

          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert("Thành công", `Tệp đã được lưu: ${download.title}`);
          setUrl("");
        } catch (error) {
          Alert.alert("Lỗi", "Không thể lưu tệp");
        }
      } else {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        Alert.alert("Lỗi", result.error || "Không thể tải tệp");
      }
      setIsLoading(false);
    },
    onError: (error) => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Lỗi", error.message || "Có lỗi xảy ra");
      setIsLoading(false);
    },
  });

  const handlePaste = async () => {
    try {
      const text = await Clipboard.getStringAsync();
      if (text) {
        setUrl(text);
      }
    } catch (error) {
      console.error("Failed to paste:", error);
    }
  };

  const handleDownload = async () => {
    if (!url.trim()) {
      Alert.alert("Lỗi", "Vui lòng nhập URL");
      return;
    }

    if (!validateUrlMutation.data?.valid) {
      Alert.alert("Lỗi", "URL không hợp lệ hoặc nền tảng không được hỗ trợ");
      return;
    }

    setIsLoading(true);
    await downloadMutation.mutateAsync({ url, quality });
  };

  const handleDelete = (id: string) => {
    Alert.alert("Xóa tệp", "Bạn có chắc muốn xóa tệp này?", [
      { text: "Hủy", style: "cancel" },
      {
        text: "Xóa",
        style: "destructive",
        onPress: () => removeDownload(id),
      },
    ]);
  };

  const isUrlValid = validateUrlMutation.data?.valid ?? false;

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2">
            <View className="flex-row items-center gap-2">
              <MaterialIcons name="download" size={28} color={colors.primary} />
              <Text
                className="text-3xl font-bold"
                style={{ color: colors.foreground }}
              >
                SnapSave Pro
              </Text>
            </View>
            <Text
              className="text-sm"
              style={{ color: colors.muted }}
            >
              Tải video và ảnh không logo từ mạng xã hội
            </Text>
          </View>

          {/* Warning Banner */}
          <View
            className="rounded-xl p-3 flex-row gap-2"
            style={{ backgroundColor: colors.warning + "20" }}
          >
            <MaterialIcons name="info" size={20} color={colors.warning} />
            <Text
              className="flex-1 text-xs"
              style={{ color: colors.warning }}
            >
              Chỉ tải nội dung bạn có quyền sử dụng
            </Text>
          </View>

          {/* Input Section */}
          <View className="gap-3">
            <InputLink
              value={url}
              onChangeText={setUrl}
              onPaste={handlePaste}
              isLoading={isLoading}
            />

            {/* Quality Selector */}
            <View className="gap-2">
              <Text
                className="text-sm font-semibold"
                style={{ color: colors.foreground }}
              >
                Chất lượng video
              </Text>
              <View className="flex-row gap-2">
                {(["sd", "hd", "full_hd"] as const).map((q) => (
                  <View
                    key={q}
                    className={`flex-1 rounded-lg py-2 px-3 items-center border ${
                      quality === q ? "border-primary" : "border-border"
                    }`}
                    style={{
                      backgroundColor: quality === q ? colors.primary + "20" : colors.surface,
                    }}
                  >
                    <Text
                      className="text-xs font-semibold uppercase"
                      style={{
                        color: quality === q ? colors.primary : colors.muted,
                      }}
                    >
                      {q === "sd" ? "SD" : q === "hd" ? "HD" : "Full HD"}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Download Button */}
            <DownloadButton
              onPress={handleDownload}
              isLoading={isLoading}
              disabled={!isUrlValid}
              title={isLoading ? "Đang tải..." : "Tải Xuống"}
            />

            {/* Platform Info */}
            {isUrlValid && validateUrlMutation.data?.platform && (
              <View
                className="rounded-lg p-3 flex-row items-center gap-2"
                style={{ backgroundColor: colors.success + "20" }}
              >
                <MaterialIcons name="check-circle" size={16} color={colors.success} />
                <Text
                  className="text-xs font-semibold uppercase"
                  style={{ color: colors.success }}
                >
                  {validateUrlMutation.data.platform} - Sẵn sàng tải
                </Text>
              </View>
            )}
          </View>

          {/* Downloads List */}
          {downloads.length > 0 && (
            <View className="gap-3">
              <View className="flex-row items-center justify-between">
                <Text
                  className="text-lg font-semibold"
                  style={{ color: colors.foreground }}
                >
                  Tệp Đã Tải ({downloads.length})
                </Text>
              </View>

              <FlatList
                scrollEnabled={false}
                data={downloads}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <DownloadCard
                    title={item.title}
                    platform={item.platform}
                    thumbnail={item.thumbnail}
                    type={item.type}
                    duration={item.duration}
                    size={item.size}
                    onDelete={() => handleDelete(item.id)}
                  />
                )}
                ItemSeparatorComponent={() => <View className="h-2" />}
              />
            </View>
          )}

          {/* Empty State */}
          {downloads.length === 0 && (
            <View className="flex-1 items-center justify-center gap-3 py-12">
              <MaterialIcons name="inbox" size={48} color={colors.muted} />
              <Text
                className="text-center text-sm"
                style={{ color: colors.muted }}
              >
                Chưa có tệp nào được tải{"\n"}Hãy bắt đầu bằng cách dán một link
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
