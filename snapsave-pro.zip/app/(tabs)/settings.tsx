import { ScrollView, View, Text, Pressable, Alert, Switch } from "react-native";
import { useState, useEffect } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useDownloads } from "@/hooks/use-downloads";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Linking from "expo-linking";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const { downloads, clearAllDownloads } = useDownloads();
  const [darkMode, setDarkMode] = useState(colorScheme === "dark");
  const [notifications, setNotifications] = useState(true);

  // Load settings on mount
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedDarkMode = await AsyncStorage.getItem("@snapsave_darkmode");
      const savedNotifications = await AsyncStorage.getItem("@snapsave_notifications");

      if (savedDarkMode !== null) setDarkMode(JSON.parse(savedDarkMode));
      if (savedNotifications !== null) setNotifications(JSON.parse(savedNotifications));
    } catch (error) {
      console.error("Failed to load settings:", error);
    }
  };

  const handleDarkModeToggle = async (value: boolean) => {
    setDarkMode(value);
    try {
      await AsyncStorage.setItem("@snapsave_darkmode", JSON.stringify(value));
      // Note: In a real app, you would trigger a theme change here
    } catch (error) {
      console.error("Failed to save dark mode setting:", error);
    }
  };

  const handleNotificationsToggle = async (value: boolean) => {
    setNotifications(value);
    try {
      await AsyncStorage.setItem("@snapsave_notifications", JSON.stringify(value));
    } catch (error) {
      console.error("Failed to save notifications setting:", error);
    }
  };

  const handleClearData = () => {
    Alert.alert("Xóa Dữ Liệu", "Bạn có chắc muốn xóa tất cả tệp đã tải?", [
      { text: "Hủy", style: "cancel" },
      {
        text: "Xóa",
        style: "destructive",
        onPress: async () => {
          try {
            await clearAllDownloads();
            Alert.alert("Thành công", "Tất cả dữ liệu đã được xóa");
          } catch (error) {
            Alert.alert("Lỗi", "Không thể xóa dữ liệu");
          }
        },
      },
    ]);
  };

  const openLink = (url: string) => {
    Linking.openURL(url).catch((err) => console.error("Failed to open URL:", err));
  };

  const SettingItem = ({
    icon,
    title,
    subtitle,
    onPress,
    toggle,
    toggleValue,
    onToggleChange,
  }: {
    icon: string;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    toggle?: boolean;
    toggleValue?: boolean;
    onToggleChange?: (value: boolean) => void;
  }) => (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
    >
      <View
        className="flex-row items-center justify-between p-4 rounded-xl"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderWidth: 1,
        }}
      >
        <View className="flex-row items-center gap-3 flex-1">
          <MaterialIcons name={icon as any} size={24} color={colors.primary} />
          <View className="flex-1">
            <Text
              className="text-base font-semibold"
              style={{ color: colors.foreground }}
            >
              {title}
            </Text>
            {subtitle && (
              <Text className="text-xs mt-1" style={{ color: colors.muted }}>
                {subtitle}
              </Text>
            )}
          </View>
        </View>
        {toggle && (
          <Switch
            value={toggleValue || false}
            onValueChange={onToggleChange}
            trackColor={{ false: colors.border, true: colors.primary + "80" }}
            thumbColor={toggleValue ? colors.primary : colors.muted}
          />
        )}
      </View>
    </Pressable>
  );

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 pb-6">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-3xl font-bold"
              style={{ color: colors.foreground }}
            >
              Cài Đặt
            </Text>
            <Text
              className="text-sm"
              style={{ color: colors.muted }}
            >
              Quản lý tùy chọn ứng dụng
            </Text>
          </View>

          {/* Display Settings */}
          <View className="gap-3">
            <Text
              className="text-lg font-semibold"
              style={{ color: colors.foreground }}
            >
              Hiển Thị
            </Text>
            <SettingItem
              icon="dark-mode"
              title="Dark Mode"
              subtitle="Chế độ tối"
              toggle
              toggleValue={darkMode}
              onToggleChange={handleDarkModeToggle}
            />
          </View>

          {/* Notification Settings */}
          <View className="gap-3">
            <Text
              className="text-lg font-semibold"
              style={{ color: colors.foreground }}
            >
              Thông Báo
            </Text>
            <SettingItem
              icon="notifications"
              title="Thông Báo"
              subtitle="Nhận thông báo khi tải xong"
              toggle
              toggleValue={notifications}
              onToggleChange={handleNotificationsToggle}
            />
          </View>

          {/* Storage Settings */}
          <View className="gap-3">
            <Text
              className="text-lg font-semibold"
              style={{ color: colors.foreground }}
            >
              Lưu Trữ
            </Text>
            <SettingItem
              icon="storage"
              title="Tệp Đã Tải"
              subtitle={`${downloads.length} tệp`}
            />
            <Pressable
              onPress={handleClearData}
              style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            >
              <View
                className="flex-row items-center gap-3 p-4 rounded-xl"
                style={{
                  backgroundColor: colors.error + "20",
                  borderColor: colors.error,
                  borderWidth: 1,
                }}
              >
                <MaterialIcons name="delete-outline" size={24} color={colors.error} />
                <Text
                  className="text-base font-semibold"
                  style={{ color: colors.error }}
                >
                  Xóa Tất Cả Dữ Liệu
                </Text>
              </View>
            </Pressable>
          </View>

          {/* About */}
          <View className="gap-3">
            <Text
              className="text-lg font-semibold"
              style={{ color: colors.foreground }}
            >
              Về Ứng Dụng
            </Text>
            <SettingItem
              icon="info"
              title="SnapSave Pro"
              subtitle="Phiên bản 1.0.0"
            />
            <SettingItem
              icon="description"
              title="Điều Khoản Sử Dụng"
              onPress={() => openLink("https://example.com/terms")}
            />
            <SettingItem
              icon="privacy-tip"
              title="Chính Sách Bảo Mật"
              onPress={() => openLink("https://example.com/privacy")}
            />
          </View>

          {/* Legal Notice */}
          <View
            className="rounded-lg p-4"
            style={{ backgroundColor: colors.warning + "20" }}
          >
            <Text
              className="text-xs leading-relaxed"
              style={{ color: colors.warning }}
            >
              ⚠️ Chỉ tải nội dung mà bạn có quyền sử dụng. SnapSave Pro không chịu trách nhiệm
              về bất kỳ vi phạm bản quyền nào.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
